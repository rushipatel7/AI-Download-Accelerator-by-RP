# AI Download Accelerator installation guide

The Chrome extension and the companion are **two separate installations**.
The companion is a program on your computer that enables accelerated
downloads. Installing the extension from the Chrome Web Store does not install
the companion automatically.

> **Before you begin:** There is no public companion download or one-command
> online installer yet. You must obtain a compatible companion package or
> project folder from the developer. Do not copy a command containing
> `YOUR_USER`, `EXTENSION_ID_PLACEHOLDER`, or another person's computer path.
> Python is not required for the setup steps in this guide.

## 1. Install the Chrome extension

1. Open Google Chrome and install **AI Download Accelerator by RP** from its
   Chrome Web Store listing.
2. Click the puzzle-piece icon in Chrome's toolbar and open **AI Download
   Accelerator**. You can pin it for easy access.
3. If the popup says the companion needs setup, continue below. You can still
   use ordinary Chrome downloads without the companion.

These instructions use the Web Store extension ID
`ilgppibegoodogiadncbdeamojfhmolm`. If you installed an unpacked developer
copy instead, see [Using an unpacked extension](#using-an-unpacked-extension).

## 2. Choose your computer

### Mac with an Apple silicon chip

1. Click the Apple menu, then **About This Mac**. If the chip starts with
   **Apple M** (for example M1, M2 or M3), follow this section. The available
   package targets macOS 11 or later.
2. Obtain `ai-download-companion-macos-apple-silicon.zip` from the developer.
   There is currently no public download link.
3. Double-click the ZIP in Finder to extract it. Open the extracted folder.
   Inside it, locate `companion`, then `scripts`, then `install_mac.sh`.
   Keep the extracted folder in a location where you will not move or delete
   it. The script and executable must remain together.
4. Open **Terminal** using Spotlight.
5. In Terminal, type the following text, including a space after `bash`:

   ```text
   bash 
   ```

6. Drag **the `install_mac.sh` file** from Finder into the Terminal window.
   Terminal adds its path. Press **Return**. Do not open the script and paste
   its contents into Terminal.
7. Wait for `Chrome native companion registered for extension ...`. If you
   see an error instead, go to [Troubleshooting](#troubleshooting).
8. Continue to [Check the connection](#3-check-the-connection).

The current Apple silicon executable is not signed by an identified developer
or notarized. macOS may block it; contact the developer for a signed,
notarized release rather than bypassing a security warning.

### Mac with an Intel processor

1. In **Apple menu > About This Mac**, check whether the processor is Intel.
   The Apple silicon package above will **not** work on an Intel Mac.
2. Obtain an Intel-compatible companion and the setup script from the developer.
   There is no public Intel package currently available.
3. If the developer supplies the complete project folder instead, install
   [Rust and Cargo](https://www.rust-lang.org/tools/install) on the Intel Mac.
   Open a new Terminal after installation. The setup script can build the
   missing companion from the source; a working Rust toolchain and the
   necessary build tools are required.
4. In the supplied project folder, find `companion/scripts/install_mac.sh`.
   In Terminal, type `bash `, drag that file into Terminal, then press
   **Return**. Keep the project folder in place.
5. Wait for the registration success message, then follow
   [Check the connection](#3-check-the-connection). If a build fails, share
   the complete error with the developer.

### Windows

> The Windows script has not yet been tested on Windows. There is no public
> Windows companion package or signed Windows release yet.

1. Obtain the project folder and a Windows companion executable from the
   developer. The executable must be located in the project folder at
   `companion\target\release\ai-download-companion.exe`. A Mac executable
   cannot run on Windows.
2. If the Windows executable is missing, the complete project source and
   [Rust and Cargo](https://www.rust-lang.org/tools/install) on Windows are
   required. Open a new PowerShell window after installing Rust. The script
   attempts to build the executable; a working Rust toolchain and its required
   Windows build tools are needed. Ask the developer for help if the build
   fails.
3. In File Explorer, open the **project folder**, the folder containing
   `companion`. Click the address bar, type `powershell`, and press **Enter**.
4. Copy this single line into PowerShell and press **Enter**:

   ```powershell
   powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\companion\scripts\install_windows.ps1
   ```

5. Wait for `Chrome native companion registered for extension ...`. Keep the
   project folder and executable in place.
6. Continue to [Check the connection](#3-check-the-connection).

## 3. Check the connection

1. In Chrome, enter `chrome://extensions` in the address bar.
2. Find **AI Download Accelerator**. Turn it off and back on, or restart
   Chrome. If Developer mode is enabled, you can also use its reload button.
3. Open the extension popup. If your version shows **Companion: Ready**, the
   connection is working. If it still needs setup, see the next section.

Registration is for the current computer user and a particular extension ID.
If you move or delete the extracted package or project folder, run the setup
script again from its new location.

## Troubleshooting

### `No such file or directory` after a `sed` command

Do not use the old `sed` command. It edits an existing file but cannot install
the companion or create a missing registration. Follow the platform steps
above; the installer creates the registration.

### `zsh: event not found: /usr/bin/env`

The script contents were pasted into Terminal. Close any opened script text,
open a fresh Terminal window, and follow the Mac instructions to type `bash `
and **drag the script file** into Terminal. Do not paste the script itself.

### `The companion binary is missing` or Cargo is not found

The script could not find a compatible executable or the Rust build tool.
For Apple silicon, extract the complete package and keep its `companion`
folder together. For Intel Mac or Windows, obtain a compatible executable, or
use the complete project source with Rust and Cargo installed as described
above. The extension folder alone does not include the companion.

### `The companion binary does not support this Mac's ... architecture`

Check **About This Mac** and use a binary built for that processor. The
available Apple silicon executable does not support Intel Macs.

### `curl` download error

There is no public companion download configured. Do not use the old
`install.sh` downloader or a placeholder URL. Obtain the appropriate package
or project folder from the developer. If another download fails, save the
complete error for support.

### The installer succeeded but Chrome still says setup is needed

1. Confirm you installed the Web Store copy, or follow the unpacked-ID steps
   below. The ID in `chrome://extensions` must match the one registered.
2. Confirm you have not moved or deleted the extracted folder or executable.
   If you moved it, rerun the installer from its new location.
3. Turn the extension off and on, then restart Chrome. Open the popup again.
4. If macOS displays a security warning, contact the developer for a signed,
   notarized companion. Do not bypass the warning.
5. If it still fails, send support the exact popup or Terminal error.

### Using an unpacked extension

In `chrome://extensions`, enable **Developer mode** and copy the unpacked
extension's 32-character ID. Run the appropriate installer with that ID:

- **Mac:** type `bash ` in Terminal, drag `install_mac.sh` into Terminal, type
  a space followed by the copied ID, and press Return.
- **Windows:** from PowerShell in the project folder, run the command below,
  replacing `YOUR_EXTENSION_ID` with the copied ID:

  ```powershell
  powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\companion\scripts\install_windows.ps1 -ExtensionId YOUR_EXTENSION_ID
  ```

The installer authorizes only the ID supplied. Run it again without an ID to
switch back to the Web Store copy.

## What to send support

Provide your operating system and version, Mac chip type if applicable,
whether the extension is from the Web Store or unpacked, the step that failed,
and the **complete error message** or a screenshot. Remove passwords, tokens,
personal paths, and other private information before sharing.

Companion setup does not activate Premium. No live Premium activation is
currently available.
