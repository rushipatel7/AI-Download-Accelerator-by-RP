use anyhow::{Context, Result};
use serde::{Deserialize, Serialize};
use tokio::io::{AsyncRead, AsyncReadExt, AsyncWrite, AsyncWriteExt};

#[derive(Debug, Deserialize, Serialize, Clone)]
#[serde(tag = "command")]
pub enum CompanionCommand {
    #[serde(rename = "START_DOWNLOAD")]
    StartDownload {
        id: String,
        url: String,
        filename: String,
        method: Option<String>,
        body: Option<String>,
        concurrency: Option<usize>,
        #[serde(rename = "chunkSize")]
        chunk_size: Option<u64>,
        #[serde(rename = "enableChunkStealing")]
        enable_chunk_stealing: Option<bool>,
        #[serde(rename = "tcpNoDelay")]
        tcp_no_delay: Option<bool>,
        #[serde(rename = "preallocateDisk")]
        preallocate_disk: Option<bool>,
        headers: Option<std::collections::HashMap<String, String>>,
    },
    #[serde(rename = "PAUSE_DOWNLOAD")]
    PauseDownload { id: String },
    #[serde(rename = "RESUME_DOWNLOAD")]
    ResumeDownload { id: String },
    #[serde(rename = "CANCEL_DOWNLOAD")]
    CancelDownload { id: String },
    #[serde(rename = "GET_STATS")]
    GetStats,
}

#[derive(Debug, Serialize, Deserialize, Clone)]
pub struct ChunkProgress {
    pub index: usize,
    pub start: u64,
    pub current: u64,
    pub end: u64,
    pub is_done: bool,
}

#[derive(Debug, Serialize, Deserialize, Clone)]
#[serde(tag = "type")]
pub enum CompanionMessage {
    #[serde(rename = "progress")]
    Progress {
        id: String,
        #[serde(rename = "downloadedBytes")]
        downloaded_bytes: u64,
        #[serde(rename = "totalBytes")]
        total_bytes: u64,
        #[serde(rename = "speedBytesPerSec")]
        speed_bytes_per_sec: u64,
        #[serde(rename = "activeConnections")]
        active_connections: usize,
        chunks: Vec<ChunkProgress>,
    },
    #[serde(rename = "completed")]
    Completed {
        id: String,
        #[serde(rename = "destPath")]
        dest_path: String,
        filename: Option<String>,
        #[serde(rename = "totalBytes")]
        total_bytes: u64,
        #[serde(rename = "sha256")]
        sha256: Option<String>,
    },
    #[serde(rename = "error")]
    Error { id: String, error: String },
    #[serde(rename = "stats")]
    Stats {
        #[serde(rename = "activeDownloads")]
        active_downloads: usize,
    },
}

/// Read a length-prefixed JSON message from an async stream (stdin)
pub async fn read_native_message<R: AsyncRead + Unpin>(
    reader: &mut R,
) -> Result<Option<CompanionCommand>> {
    let mut len_buf = [0u8; 4];
    match reader.read_exact(&mut len_buf).await {
        Ok(_) => {}
        Err(e) if e.kind() == std::io::ErrorKind::UnexpectedEof => return Ok(None),
        Err(e) => return Err(e.into()),
    }

    let length = u32::from_le_bytes(len_buf) as usize;

    if length == 0 || length > 10 * 1024 * 1024 {
        return Err(anyhow::anyhow!("Invalid message length: {}", length));
    }

    let mut msg_buf = vec![0u8; length];
    reader
        .read_exact(&mut msg_buf)
        .await
        .context("Reading message body")?;

    let cmd: CompanionCommand = serde_json::from_slice(&msg_buf).context("Parsing JSON command")?;
    Ok(Some(cmd))
}

/// Write a length-prefixed JSON message to an async stream (stdout)
pub async fn write_native_message<W: AsyncWrite + Unpin>(
    writer: &mut W,
    msg: &CompanionMessage,
) -> Result<()> {
    let json_bytes = serde_json::to_vec(msg)?;
    let length = json_bytes.len() as u32;
    let len_buf = length.to_le_bytes();

    writer.write_all(&len_buf).await?;
    writer.write_all(&json_bytes).await?;
    writer.flush().await?;
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::io::Cursor;

    #[tokio::test]
    async fn test_protocol_write_and_read_roundtrip() {
        let original_msg = CompanionMessage::Progress {
            id: "task_123".to_string(),
            downloaded_bytes: 5242880,
            total_bytes: 10485760,
            speed_bytes_per_sec: 15728640,
            active_connections: 8,
            chunks: vec![ChunkProgress {
                index: 0,
                start: 0,
                current: 5242880,
                end: 5242880,
                is_done: true,
            }],
        };

        let mut output_buf = Vec::new();
        write_native_message(&mut output_buf, &original_msg)
            .await
            .unwrap();

        // Verify 4-byte LE length header
        assert!(output_buf.len() > 4);
        let len_header =
            u32::from_le_bytes([output_buf[0], output_buf[1], output_buf[2], output_buf[3]])
                as usize;
        assert_eq!(len_header, output_buf.len() - 4);

        // Verify JSON content
        let json_str = std::str::from_utf8(&output_buf[4..]).unwrap();
        assert!(json_str.contains("task_123"));
        assert!(json_str.contains("5242880"));
    }

    #[tokio::test]
    async fn test_command_deserialization() {
        let json_cmd = r#"{
            "command": "START_DOWNLOAD",
            "id": "dl_99",
            "url": "https://example.com/test.zip",
            "filename": "test.zip",
            "concurrency": 16,
            "chunkSize": 8388608,
            "enableChunkStealing": true,
            "tcpNoDelay": true,
            "preallocateDisk": true
        }"#;

        let length = json_cmd.len() as u32;
        let mut stream_bytes = Vec::new();
        stream_bytes.extend_from_slice(&length.to_le_bytes());
        stream_bytes.extend_from_slice(json_cmd.as_bytes());

        let mut cursor = Cursor::new(stream_bytes);
        let parsed = read_native_message(&mut cursor).await.unwrap().unwrap();

        match parsed {
            CompanionCommand::StartDownload {
                id,
                url,
                filename,
                concurrency,
                ..
            } => {
                assert_eq!(id, "dl_99");
                assert_eq!(url, "https://example.com/test.zip");
                assert_eq!(filename, "test.zip");
                assert_eq!(concurrency, Some(16));
            }
            _ => panic!("Expected StartDownload command"),
        }
    }
}
