use anyhow::{Context, Result};
use futures_util::StreamExt;
use reqwest::header::{ACCEPT_ENCODING, CONTENT_LENGTH, CONTENT_RANGE, ETAG, IF_RANGE, RANGE};
use reqwest::Client;
use sha2::{Digest, Sha256};
use std::collections::HashMap;
use std::io::SeekFrom;
use std::path::{Path, PathBuf};
use std::sync::atomic::{AtomicU64, AtomicU8, Ordering};
use std::sync::Arc;
use std::time::Duration;
use tokio::fs::{File, OpenOptions};
use tokio::io::{AsyncReadExt, AsyncSeekExt, AsyncWriteExt};
use tokio::sync::mpsc::UnboundedSender;
use tokio::task::JoinSet;

use crate::protocol::{ChunkProgress, CompanionMessage};
use crate::strategy::{ChunkWorkItem, SpeedEstimator, StealingCoordinator};

pub const RUNNING: u8 = 0;
pub const PAUSED: u8 = 1;
pub const CANCELED: u8 = 2;

async fn wait_until_running(control_state: &AtomicU8) -> bool {
    loop {
        match control_state.load(Ordering::Relaxed) {
            RUNNING => return true,
            PAUSED => tokio::time::sleep(Duration::from_millis(100)).await,
            _ => return false,
        }
    }
}

fn sanitize_filename(filename: &str) -> String {
    let basename = filename
        .rsplit(|character| character == '/' || character == '\\')
        .next()
        .unwrap_or_default();
    let sanitized = basename
        .chars()
        .filter(|character| !character.is_control() && *character != ':')
        .take(180)
        .collect::<String>();
    let sanitized = sanitized.trim_matches(|character| character == '.' || character == ' ');

    if sanitized.is_empty() {
        "download".to_string()
    } else {
        sanitized.to_string()
    }
}

fn valid_content_range(value: &str, start: u64, end: u64, total: u64) -> bool {
    let Some(value) = value.strip_prefix("bytes ") else {
        return false;
    };
    let Some((range, size)) = value.split_once('/') else {
        return false;
    };
    let Some((first, last)) = range.split_once('-') else {
        return false;
    };
    first.parse::<u64>() == Ok(start)
        && last.parse::<u64>() == Ok(end)
        && size.parse::<u64>() == Ok(total)
}

async fn create_download_file(path: &Path) -> Result<File> {
    OpenOptions::new()
        .read(true)
        .write(true)
        .create_new(true)
        .open(path)
        .await
        .with_context(|| format!("Cannot create download file {}", path.display()))
}

pub struct ServerMetadata {
    pub total_bytes: u64,
    pub accept_ranges: bool,
    pub disposition_filename: Option<String>,
    pub strong_etag: Option<reqwest::header::HeaderValue>,
}

pub struct ParallelDownloader {
    client: Client,
}

impl ParallelDownloader {
    pub fn new(tcp_nodelay: bool) -> Result<Self> {
        let client = Client::builder()
            .tcp_nodelay(tcp_nodelay)
            .no_gzip()
            .no_brotli()
            .pool_max_idle_per_host(32)
            .pool_idle_timeout(Duration::from_secs(60))
            .connect_timeout(Duration::from_secs(10))
            .read_timeout(Duration::from_secs(120))
            .build()
            .context("Building reqwest client")?;

        Ok(Self { client })
    }

    fn build_request(
        &self,
        url: &str,
        method: &str,
        body: &Option<String>,
    ) -> reqwest::RequestBuilder {
        if method.eq_ignore_ascii_case("POST") {
            self.client.post(url).body(body.clone().unwrap_or_default())
        } else {
            self.client.get(url)
        }
    }

    fn reject_html_response(response: &reqwest::Response) -> Result<()> {
        let is_html = response
            .headers()
            .get(reqwest::header::CONTENT_TYPE)
            .and_then(|value| value.to_str().ok())
            .is_some_and(|value| value.to_ascii_lowercase().starts_with("text/html"));
        if is_html {
            anyhow::bail!("Server returned an HTML page instead of the requested file");
        }
        Ok(())
    }

    fn reject_encoded_response(response: &reqwest::Response) -> Result<()> {
        if let Some(encoding) = response.headers().get(reqwest::header::CONTENT_ENCODING) {
            if !encoding.to_str()?.eq_ignore_ascii_case("identity") {
                anyhow::bail!("Server returned an encoded response instead of raw file bytes");
            }
        }
        Ok(())
    }

    /// Extract filename from Content-Disposition header if present
    pub fn parse_content_disposition(header_val: &str) -> Option<String> {
        for part in header_val.split(';') {
            let trimmed = part.trim();
            if trimmed.to_lowercase().starts_with("filename*=") {
                let val = &trimmed["filename*=".len()..];
                if let Some(idx) = val.find("''") {
                    let cleaned = val[idx + 2..].trim_matches('"').trim_matches('\'');
                    if !cleaned.is_empty() {
                        return Some(cleaned.to_string());
                    }
                }
            } else if trimmed.to_lowercase().starts_with("filename=") {
                let val = &trimmed["filename=".len()..];
                let cleaned = val.trim_matches('"').trim_matches('\'');
                if !cleaned.is_empty() {
                    return Some(cleaned.to_string());
                }
            }
        }
        None
    }

    /// Probe the actual download response with a one-byte range request.
    pub async fn probe(
        &self,
        url: &str,
        method: &str,
        body: &Option<String>,
        headers: &Option<HashMap<String, String>>,
    ) -> Result<ServerMetadata> {
        let mut range_req = self
            .build_request(url, method, body)
            .header(RANGE, "bytes=0-0")
            .header(ACCEPT_ENCODING, "identity");
        if let Some(h) = headers {
            for (k, v) in h {
                range_req = range_req.header(k, v);
            }
        }

        let range_probe = range_req.send().await?.error_for_status()?;
        Self::reject_html_response(&range_probe)?;
        Self::reject_encoded_response(&range_probe)?;
        let is_partial = range_probe.status().as_u16() == 206;
        let disposition_filename = range_probe
            .headers()
            .get("content-disposition")
            .and_then(|value| value.to_str().ok())
            .and_then(Self::parse_content_disposition);
        let content_range_total = range_probe
            .headers()
            .get("content-range")
            .and_then(|value| value.to_str().ok())
            .and_then(|value| value.rsplit('/').next())
            .and_then(|value| value.parse::<u64>().ok());
        let total_bytes = content_range_total
            .or_else(|| {
                if is_partial {
                    None
                } else {
                    range_probe
                        .headers()
                        .get(CONTENT_LENGTH)
                        .and_then(|value| value.to_str().ok())
                        .and_then(|value| value.parse::<u64>().ok())
                }
            })
            .unwrap_or(0);
        let accept_ranges = is_partial
            && total_bytes > 0
            && range_probe
                .headers()
                .get(CONTENT_RANGE)
                .and_then(|value| value.to_str().ok())
                .is_some_and(|value| valid_content_range(value, 0, 0, total_bytes));
        let strong_etag = range_probe
            .headers()
            .get(ETAG)
            .filter(|value| {
                value
                    .to_str()
                    .is_ok_and(|tag| tag.len() >= 2 && tag.starts_with('"') && tag.ends_with('"'))
            })
            .cloned();

        Ok(ServerMetadata {
            total_bytes: if is_partial && !accept_ranges {
                0
            } else {
                total_bytes
            },
            accept_ranges,
            disposition_filename,
            strong_etag,
        })
    }

    /// Execute parallel or accelerated single-stream download
    pub async fn download(
        &self,
        id: String,
        url: String,
        filename: String,
        method: String,
        body: Option<String>,
        concurrency: usize,
        enable_stealing: bool,
        headers: Option<HashMap<String, String>>,
        progress_tx: UnboundedSender<CompanionMessage>,
        control_state: Arc<AtomicU8>,
    ) -> Result<PathBuf> {
        let downloads_dir = dirs::download_dir()
            .unwrap_or_else(|| PathBuf::from("."))
            .join("Accelerated");
        self.download_in_directory(
            id,
            url,
            filename,
            method,
            body,
            concurrency,
            enable_stealing,
            headers,
            progress_tx,
            control_state,
            downloads_dir,
        )
        .await
    }

    async fn download_in_directory(
        &self,
        id: String,
        url: String,
        filename: String,
        method: String,
        body: Option<String>,
        concurrency: usize,
        enable_stealing: bool,
        headers: Option<HashMap<String, String>>,
        progress_tx: UnboundedSender<CompanionMessage>,
        control_state: Arc<AtomicU8>,
        downloads_dir: PathBuf,
    ) -> Result<PathBuf> {
        tokio::fs::create_dir_all(&downloads_dir).await?;

        let meta = self.probe(&url, &method, &body, &headers).await?;

        // Determine actual filename from Content-Disposition if present
        let mut actual_filename = sanitize_filename(&filename);
        if let Some(ref disp_name) = meta.disposition_filename {
            if !disp_name.is_empty() {
                log::info!(
                    "[Downloader] Using server Content-Disposition filename: {}",
                    disp_name
                );
                actual_filename = sanitize_filename(disp_name);
            }
        }

        let dest_path = downloads_dir.join(&actual_filename);

        // Fallback for non-range servers (like dynamic PHP/Cloudflare attachment streams)
        if !meta.accept_ranges || meta.total_bytes == 0 {
            log::info!(
                "[Downloader] Single-stream pipeline for {} (Range unsupported or dynamic)",
                url
            );
            return self
                .download_single_stream(
                    id,
                    &url,
                    dest_path,
                    actual_filename,
                    meta.total_bytes,
                    &method,
                    &body,
                    &headers,
                    progress_tx,
                    control_state,
                )
                .await;
        }

        let total_bytes = meta.total_bytes;
        let actual_concurrency = concurrency.clamp(1, 32).min(total_bytes.min(32) as usize);

        // Preallocate target file (sparse / truncate)
        let main_file = create_download_file(&dest_path).await?;
        main_file.set_len(total_bytes).await?;
        drop(main_file);

        // Compute initial partitions
        let chunk_size = total_bytes / actual_concurrency as u64;
        let mut initial_chunks = Vec::new();

        for i in 0..actual_concurrency {
            let start = i as u64 * chunk_size;
            let end = if i == actual_concurrency - 1 {
                total_bytes - 1
            } else {
                ((i + 1) as u64 * chunk_size) - 1
            };
            initial_chunks.push(ChunkWorkItem::new(i, start, end));
        }

        let coordinator = StealingCoordinator::new(initial_chunks.clone(), 2 * 1024 * 1024);
        let total_downloaded = Arc::new(AtomicU64::new(0));

        // Spawn progress reporting loop
        let report_id = id.clone();
        let report_tx = progress_tx.clone();
        let report_total = total_bytes;
        let report_downloaded = total_downloaded.clone();
        let report_coordinator = coordinator.clone();
        let report_control = control_state.clone();

        let progress_handle = tokio::spawn(async move {
            let mut speed_estimator = SpeedEstimator::new(0.35);
            let mut interval = tokio::time::interval(Duration::from_millis(300));

            while report_control.load(Ordering::Relaxed) != CANCELED {
                interval.tick().await;
                let current_bytes = report_downloaded.load(Ordering::Relaxed);
                let speed = speed_estimator.update(current_bytes);

                let all_chunks = report_coordinator.get_all_chunks().await;
                let chunk_progress: Vec<ChunkProgress> = all_chunks
                    .iter()
                    .map(|c| ChunkProgress {
                        index: c.index,
                        start: c.start,
                        current: c.current.load(Ordering::Relaxed),
                        end: c.end.load(Ordering::Relaxed),
                        is_done: c.is_done.load(Ordering::Relaxed),
                    })
                    .collect();

                let _ = report_tx.send(CompanionMessage::Progress {
                    id: report_id.clone(),
                    downloaded_bytes: current_bytes,
                    total_bytes: report_total,
                    speed_bytes_per_sec: speed,
                    active_connections: actual_concurrency,
                    chunks: chunk_progress,
                });

                if current_bytes >= report_total {
                    break;
                }
            }
        });

        // Spawn worker pool
        let mut join_set = JoinSet::new();

        for worker_id in 0..actual_concurrency {
            let worker_client = self.client.clone();
            let worker_url = url.clone();
            let worker_path = dest_path.clone();
            let worker_coordinator = coordinator.clone();
            let worker_total_downloaded = total_downloaded.clone();
            let worker_control = control_state.clone();
            let worker_headers = headers.clone();
            let worker_method = method.clone();
            let worker_body = body.clone();
            let worker_etag = meta.strong_etag.clone();
            let initial_work = initial_chunks[worker_id].clone();

            join_set.spawn(async move {
                let mut current_task = Some(initial_work);

                while let Some(work) = current_task {
                    if !wait_until_running(&worker_control).await {
                        break;
                    }

                    let mut file = match OpenOptions::new().write(true).open(&worker_path).await {
                        Ok(f) => f,
                        Err(e) => {
                            log::error!("Worker {} file open error: {:?}", worker_id, e);
                            break;
                        }
                    };

                    let mut retry_count = 0;
                    while retry_count < 4 && worker_control.load(Ordering::Relaxed) != CANCELED {
                        if !wait_until_running(&worker_control).await {
                            break;
                        }

                        let start = work.current.load(Ordering::Relaxed);
                        let end = work.end.load(Ordering::Relaxed);

                        if start > end {
                            break;
                        }

                        let range_header = format!("bytes={}-{}", start, end);
                        let mut req = if worker_method.eq_ignore_ascii_case("POST") {
                            worker_client
                                .post(&worker_url)
                                .body(worker_body.clone().unwrap_or_default())
                        } else {
                            worker_client.get(&worker_url)
                        }
                        .header(RANGE, range_header)
                        .header(ACCEPT_ENCODING, "identity");

                        if let Some(ref h) = worker_headers {
                            for (k, v) in h {
                                req = req.header(k, v);
                            }
                        }
                        if let Some(ref etag) = worker_etag {
                            req = req.header(IF_RANGE, etag.clone());
                        }

                        match req.send().await {
                            Ok(resp) if resp.status().as_u16() == 206 => {
                                if let (Some(expected), Some(actual)) =
                                    (&worker_etag, resp.headers().get(ETAG))
                                {
                                    if expected != actual {
                                        log::error!("Worker {} received a changed file", worker_id);
                                        break;
                                    }
                                }
                                let valid_range = resp
                                    .headers()
                                    .get(CONTENT_RANGE)
                                    .and_then(|value| value.to_str().ok())
                                    .is_some_and(|value| {
                                        valid_content_range(value, start, end, total_bytes)
                                    });
                                if !valid_range {
                                    log::error!(
                                        "Worker {} received an invalid Content-Range",
                                        worker_id
                                    );
                                    break;
                                }
                                if let Err(e) = Self::reject_html_response(&resp) {
                                    log::error!(
                                        "Worker {} received invalid response: {:?}",
                                        worker_id,
                                        e
                                    );
                                    break;
                                }
                                if let Err(e) = Self::reject_encoded_response(&resp) {
                                    log::error!(
                                        "Worker {} received invalid response: {:?}",
                                        worker_id,
                                        e
                                    );
                                    break;
                                }
                                let mut stream = resp.bytes_stream();
                                let mut file_offset = start;

                                if let Err(e) = file.seek(SeekFrom::Start(file_offset)).await {
                                    log::error!("Seek failed: {:?}", e);
                                    break;
                                }

                                while let Some(chunk_res) = stream.next().await {
                                    if !wait_until_running(&worker_control).await {
                                        break;
                                    }

                                    let chunk = match chunk_res {
                                        Ok(b) => b,
                                        Err(e) => {
                                            log::warn!("Chunk stream error: {:?}", e);
                                            break;
                                        }
                                    };

                                    let chunk_len = chunk.len() as u64;
                                    let current_end = work.end.load(Ordering::Relaxed);
                                    if file_offset + chunk_len > current_end + 1 {
                                        let allowed =
                                            (current_end + 1).saturating_sub(file_offset) as usize;
                                        if allowed > 0 {
                                            if let Err(e) = file.write_all(&chunk[..allowed]).await
                                            {
                                                log::error!("File write failed: {:?}", e);
                                                break;
                                            }
                                            file_offset += allowed as u64;
                                            work.current.store(file_offset, Ordering::Relaxed);
                                            worker_total_downloaded
                                                .fetch_add(allowed as u64, Ordering::Relaxed);
                                        }
                                        break;
                                    }

                                    if let Err(e) = file.write_all(&chunk).await {
                                        log::error!("File write failed: {:?}", e);
                                        break;
                                    }

                                    file_offset += chunk_len;
                                    work.current.store(file_offset, Ordering::Relaxed);
                                    worker_total_downloaded.fetch_add(chunk_len, Ordering::Relaxed);
                                }
                                break;
                            }
                            other => {
                                retry_count += 1;
                                log::warn!(
                                    "Worker {} retry {}/4 (status: {:?})",
                                    worker_id,
                                    retry_count,
                                    other.map(|r| r.status())
                                );
                                tokio::time::sleep(Duration::from_millis(15 * retry_count as u64))
                                    .await;
                            }
                        }
                    }

                    work.is_done.store(true, Ordering::Relaxed);

                    // Dynamic Chunk Stealing
                    if enable_stealing && worker_control.load(Ordering::Relaxed) != CANCELED {
                        current_task = worker_coordinator.attempt_steal(worker_id).await;
                    } else {
                        current_task = None;
                    }
                }
            });
        }

        // Await all workers
        while let Some(res) = join_set.join_next().await {
            if let Err(e) = res {
                log::error!("Worker join error: {:?}", e);
            }
        }

        progress_handle.abort();

        if control_state.load(Ordering::Relaxed) == CANCELED {
            let _ = tokio::fs::remove_file(&dest_path).await;
            return Err(anyhow::anyhow!("Download cancelled by user"));
        }

        let downloaded_bytes = total_downloaded.load(Ordering::Relaxed);
        if downloaded_bytes != total_bytes {
            let _ = tokio::fs::remove_file(&dest_path).await;
            return Err(anyhow::anyhow!(
                "Download incomplete: received {} of {} bytes; server may not support byte ranges",
                downloaded_bytes,
                total_bytes
            ));
        }

        // Fast streaming SHA-256 verification
        let sha256_hash = Some(Self::calculate_hash(&dest_path).await?);

        let _ = progress_tx.send(CompanionMessage::Completed {
            id,
            dest_path: dest_path.to_string_lossy().to_string(),
            filename: Some(actual_filename),
            total_bytes,
            sha256: sha256_hash,
        });

        Ok(dest_path)
    }

    /// Single stream fallback with header forwarding and Content-Disposition handling
    async fn download_single_stream(
        &self,
        id: String,
        url: &str,
        mut dest_path: PathBuf,
        mut filename: String,
        mut total_bytes: u64,
        method: &str,
        body: &Option<String>,
        headers: &Option<HashMap<String, String>>,
        progress_tx: UnboundedSender<CompanionMessage>,
        control_state: Arc<AtomicU8>,
    ) -> Result<PathBuf> {
        let mut req = self
            .build_request(url, method, body)
            .header(ACCEPT_ENCODING, "identity");
        if let Some(h) = headers {
            for (k, v) in h {
                req = req.header(k, v);
            }
        }

        let resp = req.send().await?.error_for_status()?;
        Self::reject_html_response(&resp)?;
        Self::reject_encoded_response(&resp)?;
        if resp.status() == reqwest::StatusCode::PARTIAL_CONTENT {
            anyhow::bail!("Server returned a partial response to a full download request");
        }

        // Check if server returned a real filename via Content-Disposition
        if let Some(cd) = resp.headers().get("content-disposition") {
            if let Ok(s) = cd.to_str() {
                if let Some(real_name) = Self::parse_content_disposition(s) {
                    if !real_name.is_empty() {
                        log::info!(
                            "[Downloader] Single-stream Content-Disposition filename: {}",
                            real_name
                        );
                        filename = sanitize_filename(&real_name);
                        dest_path = dest_path.parent().unwrap_or(Path::new(".")).join(&filename);
                    }
                }
            }
        }

        if total_bytes == 0 {
            if let Some(cl) = resp.headers().get(CONTENT_LENGTH) {
                if let Ok(s) = cl.to_str() {
                    total_bytes = s.parse::<u64>().unwrap_or(0);
                }
            }
        }

        let mut stream = resp.bytes_stream();

        let mut file = create_download_file(&dest_path).await?;

        let mut downloaded = 0u64;
        let mut speed_est = SpeedEstimator::new(0.35);

        while let Some(chunk_res) = stream.next().await {
            if !wait_until_running(&control_state).await {
                if control_state.load(Ordering::Relaxed) == CANCELED {
                    let _ = tokio::fs::remove_file(&dest_path).await;
                    return Err(anyhow::anyhow!("Cancelled"));
                }
                continue;
            }

            if control_state.load(Ordering::Relaxed) == CANCELED {
                let _ = tokio::fs::remove_file(&dest_path).await;
                return Err(anyhow::anyhow!("Cancelled"));
            }

            let chunk = chunk_res?;
            file.write_all(&chunk).await?;
            downloaded += chunk.len() as u64;

            let speed = speed_est.update(downloaded);
            let _ = progress_tx.send(CompanionMessage::Progress {
                id: id.clone(),
                downloaded_bytes: downloaded,
                total_bytes: if total_bytes > 0 {
                    total_bytes
                } else {
                    downloaded
                },
                speed_bytes_per_sec: speed,
                active_connections: 1,
                chunks: vec![ChunkProgress {
                    index: 0,
                    start: 0,
                    current: downloaded,
                    end: if total_bytes > 0 {
                        total_bytes
                    } else {
                        downloaded
                    },
                    is_done: downloaded == total_bytes && total_bytes > 0,
                }],
            });
        }

        if total_bytes > 0 && downloaded != total_bytes {
            tokio::fs::remove_file(&dest_path).await?;
            anyhow::bail!("Download incomplete: received {downloaded} of {total_bytes} bytes");
        }
        let sha256_hash = Some(Self::calculate_hash(&dest_path).await?);

        let _ = progress_tx.send(CompanionMessage::Completed {
            id,
            dest_path: dest_path.to_string_lossy().to_string(),
            filename: Some(filename),
            total_bytes: downloaded,
            sha256: sha256_hash,
        });

        Ok(dest_path)
    }

    async fn calculate_hash(path: &Path) -> Result<String> {
        let mut file = File::open(path).await?;
        let mut hasher = Sha256::new();
        let mut buf = [0u8; 64 * 1024];

        loop {
            let n = file.read(&mut buf).await?;
            if n == 0 {
                break;
            }
            hasher.update(&buf[..n]);
        }

        Ok(format!("{:x}", hasher.finalize()))
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use tokio::io::{AsyncReadExt, AsyncWriteExt};
    use tokio::net::TcpListener;

    #[test]
    fn content_range_must_match_requested_bytes_and_total() {
        assert!(valid_content_range("bytes 0-0/123", 0, 0, 123));
        assert!(valid_content_range("bytes 20-29/123", 20, 29, 123));
        for invalid in [
            "bytes 0-1/123",
            "bytes 20-29/124",
            "bytes 21-29/123",
            "bytes 20-29/*",
            "bytes 20-29/123junk",
            "items 20-29/123",
        ] {
            assert!(!valid_content_range(invalid, 20, 29, 123));
        }
    }

    #[tokio::test]
    async fn creating_download_does_not_overwrite_existing_file() {
        let path = std::env::temp_dir().join(format!(
            "ai-downloader-existing-{}-{}",
            std::process::id(),
            std::time::SystemTime::now()
                .duration_since(std::time::UNIX_EPOCH)
                .unwrap()
                .as_nanos()
        ));
        tokio::fs::write(&path, b"existing content").await.unwrap();
        let result = create_download_file(&path).await;
        assert!(result.is_err());
        assert_eq!(tokio::fs::read(&path).await.unwrap(), b"existing content");
        tokio::fs::remove_file(path).await.unwrap();
    }

    #[tokio::test]
    async fn malformed_probe_range_disables_parallel_downloads() {
        let listener = TcpListener::bind("127.0.0.1:0").await.unwrap();
        let address = listener.local_addr().unwrap();
        let server = tokio::spawn(async move {
            let (mut socket, _) = listener.accept().await.unwrap();
            let mut request = [0; 1024];
            socket.read(&mut request).await.unwrap();
            socket.write_all(b"HTTP/1.1 206 Partial Content\r\nContent-Length: 1\r\nContent-Range: bytes 1-1/4\r\nConnection: close\r\n\r\nb").await.unwrap();
        });
        let downloader = ParallelDownloader::new(true).unwrap();
        let metadata = downloader
            .probe(&format!("http://{address}/file"), "GET", &None, &None)
            .await
            .unwrap();
        assert!(!metadata.accept_ranges);
        assert_eq!(metadata.total_bytes, 0);
        server.await.unwrap();
    }

    #[tokio::test]
    async fn single_stream_download_writes_expected_file_and_hash() {
        let listener = TcpListener::bind("127.0.0.1:0").await.unwrap();
        let address = listener.local_addr().unwrap();
        let server = tokio::spawn(async move {
            let (mut socket, _) = listener.accept().await.unwrap();
            let mut request = [0; 1024];
            socket.read(&mut request).await.unwrap();
            socket
                .write_all(b"HTTP/1.1 200 OK\r\nContent-Length: 3\r\nConnection: close\r\n\r\nabc")
                .await
                .unwrap();
        });
        let path = std::env::temp_dir().join(format!(
            "ai-downloader-stream-{}-{}",
            std::process::id(),
            std::time::SystemTime::now()
                .duration_since(std::time::UNIX_EPOCH)
                .unwrap()
                .as_nanos()
        ));
        let (tx, mut rx) = tokio::sync::mpsc::unbounded_channel();
        let downloader = ParallelDownloader::new(true).unwrap();
        downloader
            .download_single_stream(
                "test".into(),
                &format!("http://{address}/file"),
                path.clone(),
                "file".into(),
                3,
                "GET",
                &None,
                &None,
                tx,
                Arc::new(AtomicU8::new(RUNNING)),
            )
            .await
            .unwrap();
        assert_eq!(tokio::fs::read(&path).await.unwrap(), b"abc");
        let mut completed = None;
        while let Ok(message) = rx.try_recv() {
            if let CompanionMessage::Completed { sha256, .. } = message {
                completed = sha256;
            }
        }
        assert_eq!(
            completed.as_deref(),
            Some("ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad")
        );
        tokio::fs::remove_file(path).await.unwrap();
        server.await.unwrap();
    }

    async fn test_parallel_download(invalid_worker_range: bool, changed_etag: bool) {
        let listener = TcpListener::bind("127.0.0.1:0").await.unwrap();
        let address = listener.local_addr().unwrap();
        let server = tokio::spawn(async move {
            let data = b"abcdefghijkl";
            for _ in 0..4 {
                let (mut socket, _) = listener.accept().await.unwrap();
                let mut request = [0; 4096];
                let read = socket.read(&mut request).await.unwrap();
                let request = String::from_utf8_lossy(&request[..read]);
                let range = request
                    .lines()
                    .find_map(|line| {
                        let (name, value) = line.split_once(':')?;
                        name.eq_ignore_ascii_case("range").then_some(value.trim())
                    })
                    .unwrap()
                    .strip_prefix("bytes=")
                    .unwrap();
                let (start, end) = range.split_once('-').unwrap();
                let start = start.parse::<usize>().unwrap();
                let end = end.parse::<usize>().unwrap();
                let is_probe = start == 0 && end == 0;
                if !is_probe {
                    assert!(request
                        .lines()
                        .any(|line| line.eq_ignore_ascii_case("if-range: \"original\"")));
                }
                let advertised_start = if invalid_worker_range && (start != 0 || end != 0) {
                    start + 1
                } else {
                    start
                };
                let header = format!(
                    "HTTP/1.1 206 Partial Content\r\nContent-Length: {}\r\nContent-Range: bytes {}-{}/12\r\nETag: \"{}\"\r\nConnection: close\r\n\r\n",
                    end - start + 1,
                    advertised_start,
                    end,
                    if changed_etag && !is_probe { "changed" } else { "original" }
                );
                socket.write_all(header.as_bytes()).await.unwrap();
                socket.write_all(&data[start..=end]).await.unwrap();
            }
        });
        let directory = std::env::temp_dir().join(format!(
            "ai-downloader-parallel-{}-{}",
            std::process::id(),
            std::time::SystemTime::now()
                .duration_since(std::time::UNIX_EPOCH)
                .unwrap()
                .as_nanos()
        ));
        let (tx, mut rx) = tokio::sync::mpsc::unbounded_channel();
        let downloader = ParallelDownloader::new(true).unwrap();
        let result = downloader
            .download_in_directory(
                "test".into(),
                format!("http://{address}/file"),
                "file.bin".into(),
                "GET".into(),
                None,
                3,
                false,
                None,
                tx,
                Arc::new(AtomicU8::new(RUNNING)),
                directory.clone(),
            )
            .await;
        server.await.unwrap();
        let path = directory.join("file.bin");
        if invalid_worker_range || changed_etag {
            assert!(result.is_err());
            assert!(!path.exists());
        } else {
            assert_eq!(result.unwrap(), path);
            assert_eq!(tokio::fs::read(&path).await.unwrap(), b"abcdefghijkl");
            let mut completed = false;
            while let Ok(message) = rx.try_recv() {
                completed |= matches!(message, CompanionMessage::Completed { .. });
            }
            assert!(completed);
            tokio::fs::remove_file(path).await.unwrap();
        }
        tokio::fs::remove_dir(directory).await.unwrap();
    }

    #[tokio::test]
    async fn parallel_download_writes_exact_requested_bytes() {
        test_parallel_download(false, false).await;
    }

    #[tokio::test]
    async fn parallel_download_rejects_mismatched_ranges_and_removes_partial_file() {
        test_parallel_download(true, false).await;
    }

    #[tokio::test]
    async fn parallel_download_rejects_changed_etag_and_removes_partial_file() {
        test_parallel_download(false, true).await;
    }

    #[test]
    fn server_filename_cannot_escape_download_directory() {
        assert_eq!(sanitize_filename("../../outside.mp4"), "outside.mp4");
        assert_eq!(sanitize_filename("..\\..\\outside.mp4"), "outside.mp4");
        assert_eq!(sanitize_filename("..."), "download");
        assert_eq!(sanitize_filename("safe\nname.mp4"), "safename.mp4");
        assert!(sanitize_filename(&"a".repeat(300)).len() <= 180);
    }

    #[tokio::test]
    async fn pause_waits_until_resumed() {
        let control_state = Arc::new(AtomicU8::new(PAUSED));
        let resume_state = control_state.clone();
        let resume_task = tokio::spawn(async move {
            tokio::time::sleep(Duration::from_millis(20)).await;
            resume_state.store(RUNNING, Ordering::Relaxed);
        });

        assert!(wait_until_running(&control_state).await);
        resume_task.await.unwrap();
    }

    #[tokio::test]
    async fn cancel_interrupts_a_paused_download() {
        let control_state = AtomicU8::new(CANCELED);
        assert!(!wait_until_running(&control_state).await);
    }

    #[tokio::test]
    async fn probe_preserves_post_body_and_uses_range_response_metadata() {
        let listener = TcpListener::bind("127.0.0.1:0").await.unwrap();
        let address = listener.local_addr().unwrap();
        let (request_tx, request_rx) = tokio::sync::oneshot::channel();

        tokio::spawn(async move {
            let (mut socket, _) = listener.accept().await.unwrap();
            let mut request = Vec::new();
            let mut buffer = [0; 1024];
            loop {
                let read = socket.read(&mut buffer).await.unwrap();
                if read == 0 {
                    break;
                }
                request.extend_from_slice(&buffer[..read]);

                if let Some(header_end) = request.windows(4).position(|w| w == b"\r\n\r\n") {
                    let header = String::from_utf8_lossy(&request[..header_end]);
                    let content_length = header
                        .lines()
                        .find_map(|line| {
                            let (name, value) = line.split_once(':')?;
                            name.eq_ignore_ascii_case("content-length")
                                .then(|| value.trim().parse::<usize>().ok())
                                .flatten()
                        })
                        .unwrap_or(0);
                    if request.len() >= header_end + 4 + content_length {
                        break;
                    }
                }
            }
            let request = String::from_utf8_lossy(&request).into_owned();
            let _ = request_tx.send(request);

            let response = "HTTP/1.1 206 Partial Content\r\nContent-Type: video/mp4\r\nContent-Length: 1\r\nContent-Range: bytes 0-0/209715200\r\nContent-Disposition: attachment; filename=\"dummy.mp4\"\r\nConnection: close\r\n\r\nx";
            socket.write_all(response.as_bytes()).await.unwrap();
        });

        let downloader = ParallelDownloader::new(true).unwrap();
        let metadata = downloader
            .probe(
                &format!("http://{address}/download/video"),
                "POST",
                &Some("size=1GB&_token=test-token".to_string()),
                &None,
            )
            .await
            .unwrap();
        let request = request_rx.await.unwrap();

        assert!(request.starts_with("POST /download/video "));
        assert!(request.to_ascii_lowercase().contains("range: bytes=0-0"));
        assert!(request.contains("size=1GB&_token=test-token"));
        assert_eq!(metadata.total_bytes, 209_715_200);
        assert!(metadata.accept_ranges);
        assert_eq!(metadata.disposition_filename.as_deref(), Some("dummy.mp4"));
    }

    #[tokio::test]
    async fn probe_rejects_html_pages_instead_of_treating_them_as_downloads() {
        let listener = TcpListener::bind("127.0.0.1:0").await.unwrap();
        let address = listener.local_addr().unwrap();

        tokio::spawn(async move {
            let (mut socket, _) = listener.accept().await.unwrap();
            let mut request = [0; 1024];
            let _ = socket.read(&mut request).await.unwrap();
            socket
                .write_all(
                    b"HTTP/1.1 200 OK\r\nContent-Type: text/html\r\nContent-Length: 13\r\nConnection: close\r\n\r\n<html>oops</html>",
                )
                .await
                .unwrap();
        });

        let downloader = ParallelDownloader::new(true).unwrap();
        let error = match downloader
            .probe(&format!("http://{address}/download"), "GET", &None, &None)
            .await
        {
            Ok(_) => panic!("Expected an HTML response to be rejected"),
            Err(error) => error,
        };

        assert!(error
            .to_string()
            .contains("HTML page instead of the requested file"));
    }
}
