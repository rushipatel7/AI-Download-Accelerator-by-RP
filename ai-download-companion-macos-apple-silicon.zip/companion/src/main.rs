mod downloader;
mod protocol;
mod strategy;

use anyhow::Result;
use protocol::{read_native_message, write_native_message, CompanionCommand, CompanionMessage};
use std::collections::HashMap;
use std::sync::atomic::{AtomicU8, Ordering};
use std::sync::Arc;
use tokio::io::{stdin, stdout};
use tokio::sync::{mpsc, RwLock};

#[tokio::main]
async fn main() -> Result<()> {
    // Note: Do not write arbitrary logs to stdout because stdout is reserved for Native Messaging!
    // Write logs to stderr instead.
    env_logger::Builder::from_env(env_logger::Env::default().default_filter_or("info"))
        .target(env_logger::Target::Stderr)
        .init();

    log::info!("AI Download Companion daemon starting...");

    let mut stdin_reader = stdin();
    let mut stdout_writer = stdout();

    let (tx, mut rx) = mpsc::unbounded_channel::<CompanionMessage>();

    // Dedicated writer task to handle all stdout framing
    let writer_handle = tokio::spawn(async move {
        while let Some(msg) = rx.recv().await {
            if let Err(e) = write_native_message(&mut stdout_writer, &msg).await {
                log::error!("Failed to write native message to stdout: {:?}", e);
                break;
            }
        }
    });

    let active_tasks: Arc<RwLock<HashMap<String, Arc<AtomicU8>>>> =
        Arc::new(RwLock::new(HashMap::new()));

    // Main read loop from Chrome stdin
    loop {
        match read_native_message(&mut stdin_reader).await {
            Ok(Some(command)) => match command {
                CompanionCommand::StartDownload {
                    id,
                    url,
                    filename,
                    method,
                    body,
                    concurrency,
                    enable_chunk_stealing,
                    tcp_no_delay,
                    headers,
                    ..
                } => {
                    log::info!("Received START_DOWNLOAD for [{}] -> {}", filename, url);
                    let control_state = Arc::new(AtomicU8::new(downloader::RUNNING));
                    active_tasks
                        .write()
                        .await
                        .insert(id.clone(), control_state.clone());

                    let progress_tx = tx.clone();
                    let task_id = id.clone();
                    let active_tasks_ref = active_tasks.clone();
                    let concurrency_val = concurrency.unwrap_or(8);
                    let enable_stealing = enable_chunk_stealing.unwrap_or(true);
                    let no_delay = tcp_no_delay.unwrap_or(true);

                    tokio::spawn(async move {
                        match downloader::ParallelDownloader::new(no_delay) {
                            Ok(dl) => {
                                if let Err(e) = dl
                                    .download(
                                        task_id.clone(),
                                        url,
                                        filename,
                                        method.unwrap_or_else(|| "GET".to_string()),
                                        body,
                                        concurrency_val,
                                        enable_stealing,
                                        headers,
                                        progress_tx.clone(),
                                        control_state,
                                    )
                                    .await
                                {
                                    log::error!("Download error: {:?}", e);
                                    let _ = progress_tx.send(CompanionMessage::Error {
                                        id: task_id.clone(),
                                        error: e.to_string(),
                                    });
                                }
                            }
                            Err(e) => {
                                let _ = progress_tx.send(CompanionMessage::Error {
                                    id: task_id.clone(),
                                    error: format!("Downloader init error: {}", e),
                                });
                            }
                        }
                        active_tasks_ref.write().await.remove(&task_id);
                    });
                }

                CompanionCommand::CancelDownload { id } => {
                    log::info!("Received CANCEL_DOWNLOAD for [{}]", id);
                    if let Some(signal) = active_tasks.read().await.get(&id) {
                        signal.store(downloader::CANCELED, Ordering::Relaxed);
                    }
                }

                CompanionCommand::PauseDownload { id } => {
                    log::info!("Received PAUSE_DOWNLOAD for [{}]", id);
                    if let Some(signal) = active_tasks.read().await.get(&id) {
                        signal.store(downloader::PAUSED, Ordering::Relaxed);
                    }
                }

                CompanionCommand::ResumeDownload { id } => {
                    log::info!("Received RESUME_DOWNLOAD for [{}]", id);
                    if let Some(signal) = active_tasks.read().await.get(&id) {
                        signal.store(downloader::RUNNING, Ordering::Relaxed);
                    }
                }

                CompanionCommand::GetStats => {
                    let count = active_tasks.read().await.len();
                    let _ = tx.send(CompanionMessage::Stats {
                        active_downloads: count,
                    });
                }
            },
            Ok(None) => {
                log::info!("Chrome closed native messaging connection (EOF). Exiting companion.");
                break;
            }
            Err(e) => {
                log::error!("Native messaging stream read error: {:?}", e);
                break;
            }
        }
    }

    drop(tx);
    let _ = writer_handle.await;
    Ok(())
}
