use std::sync::atomic::{AtomicBool, AtomicU64, Ordering};
use std::sync::Arc;
use tokio::sync::RwLock;

/// Range representation for a worker thread chunk
#[derive(Debug, Clone)]
pub struct ChunkWorkItem {
    pub index: usize,
    pub start: u64,
    pub current: Arc<AtomicU64>,
    pub end: Arc<AtomicU64>,
    pub is_done: Arc<AtomicBool>,
}

impl ChunkWorkItem {
    pub fn new(index: usize, start: u64, end: u64) -> Self {
        Self {
            index,
            start,
            current: Arc::new(AtomicU64::new(start)),
            end: Arc::new(AtomicU64::new(end)),
            is_done: Arc::new(AtomicBool::new(false)),
        }
    }

    /// Bytes remaining in this chunk
    pub fn remaining(&self) -> u64 {
        let cur = self.current.load(Ordering::Relaxed);
        let end = self.end.load(Ordering::Relaxed);
        if end > cur {
            end - cur
        } else {
            0
        }
    }
}

/// Dynamic Work Stealing Coordinator
#[derive(Clone)]
pub struct StealingCoordinator {
    chunks: Arc<RwLock<Vec<ChunkWorkItem>>>,
    min_steal_bytes: u64,
}

impl StealingCoordinator {
    pub fn new(chunks: Vec<ChunkWorkItem>, min_steal_bytes: u64) -> Self {
        Self {
            chunks: Arc::new(RwLock::new(chunks)),
            min_steal_bytes,
        }
    }

    /// Find the slowest or largest lagging chunk and steal its upper half
    pub async fn attempt_steal(&self, stealer_index: usize) -> Option<ChunkWorkItem> {
        let mut chunks_guard = self.chunks.write().await;
        let mut target_index: Option<usize> = None;
        let mut max_remaining = 0u64;

        for (idx, item) in chunks_guard.iter().enumerate() {
            if !item.is_done.load(Ordering::Relaxed) {
                let rem = item.remaining();
                if rem > self.min_steal_bytes && rem > max_remaining {
                    max_remaining = rem;
                    target_index = Some(idx);
                }
            }
        }

        if let Some(target_idx) = target_index {
            let target = &mut chunks_guard[target_idx];
            let current = target.current.load(Ordering::SeqCst);
            let old_end = target.end.load(Ordering::SeqCst);
            let rem = if old_end > current {
                old_end - current
            } else {
                0
            };

            if rem >= self.min_steal_bytes {
                let split_point = current + (rem / 2);
                // Truncate the original chunk
                target.end.store(split_point, Ordering::SeqCst);

                // Create new stolen work item
                let stolen = ChunkWorkItem::new(chunks_guard.len(), split_point + 1, old_end);
                chunks_guard.push(stolen.clone());
                log::info!(
                    "[AI Chunk Stealer] Worker {} stole range {}-{} from worker {}",
                    stealer_index,
                    split_point + 1,
                    old_end,
                    target_idx
                );
                return Some(stolen);
            }
        }

        None
    }

    pub async fn get_all_chunks(&self) -> Vec<ChunkWorkItem> {
        self.chunks.read().await.clone()
    }
}

/// Adaptive Throughput Smoother using Exponential Moving Average (EMA)
pub struct SpeedEstimator {
    alpha: f64,
    last_speed: f64,
    last_bytes: u64,
    last_time: tokio::time::Instant,
}

impl SpeedEstimator {
    pub fn new(alpha: f64) -> Self {
        Self {
            alpha,
            last_speed: 0.0,
            last_bytes: 0,
            last_time: tokio::time::Instant::now(),
        }
    }

    pub fn update(&mut self, current_bytes: u64) -> u64 {
        let now = tokio::time::Instant::now();
        let elapsed = now.duration_since(self.last_time).as_secs_f64();
        if elapsed < 0.25 {
            return self.last_speed as u64;
        }

        let delta_bytes = if current_bytes >= self.last_bytes {
            current_bytes - self.last_bytes
        } else {
            0
        };

        let instant_speed = delta_bytes as f64 / elapsed;
        self.last_speed = if self.last_speed == 0.0 {
            instant_speed
        } else {
            (self.alpha * instant_speed) + ((1.0 - self.alpha) * self.last_speed)
        };

        self.last_bytes = current_bytes;
        self.last_time = now;
        self.last_speed.round() as u64
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[tokio::test]
    async fn test_chunk_work_item_remaining() {
        let chunk = ChunkWorkItem::new(0, 0, 1000);
        assert_eq!(chunk.remaining(), 1000);

        chunk.current.store(400, Ordering::SeqCst);
        assert_eq!(chunk.remaining(), 600);

        chunk.current.store(1000, Ordering::SeqCst);
        assert_eq!(chunk.remaining(), 0);
    }

    #[tokio::test]
    async fn test_stealing_coordinator_bisects_straggler() {
        // Worker 0 has completed its chunk (0 to 1000)
        let chunk0 = ChunkWorkItem::new(0, 0, 1000);
        chunk0.current.store(1000, Ordering::SeqCst);
        chunk0.is_done.store(true, Ordering::SeqCst);

        // Worker 1 is lagging behind with 10MB (start: 1000, cur: 2000, end: 10_002_000)
        // remaining = 10_000_000 bytes
        let chunk1 = ChunkWorkItem::new(1, 1000, 10_002_000);
        chunk1.current.store(2000, Ordering::SeqCst);

        let coordinator = StealingCoordinator::new(vec![chunk0, chunk1], 2 * 1024 * 1024);

        // Worker 0 attempts to steal
        let stolen = coordinator.attempt_steal(0).await;
        assert!(
            stolen.is_some(),
            "Expected chunk stealing to succeed on straggler"
        );

        let stolen_item = stolen.unwrap();
        // The split point should be cur + (10_000_000 / 2) = 2000 + 5_000_000 = 5_002_000
        // Stolen chunk should cover 5_002_001 to 10_002_000
        assert_eq!(stolen_item.start, 5_002_001);
        assert_eq!(stolen_item.end.load(Ordering::SeqCst), 10_002_000);

        // Check that original chunk1 end was truncated to split_point
        let all_chunks = coordinator.get_all_chunks().await;
        assert_eq!(all_chunks[1].end.load(Ordering::SeqCst), 5_002_000);
    }

    #[tokio::test]
    async fn test_stealing_coordinator_rejects_small_chunks() {
        // Chunk only has 500KB remaining (< min_steal_bytes of 2MB)
        let chunk0 = ChunkWorkItem::new(0, 0, 500_000);
        chunk0.current.store(0, Ordering::SeqCst);

        let coordinator = StealingCoordinator::new(vec![chunk0], 2 * 1024 * 1024);
        let stolen = coordinator.attempt_steal(1).await;
        assert!(
            stolen.is_none(),
            "Should not steal when remaining bytes < min_steal_bytes"
        );
    }

    #[test]
    fn test_speed_estimator_smoothing() {
        let mut est = SpeedEstimator::new(0.5);
        // Initially 0
        assert_eq!(est.update(0), 0);
    }
}
