#!/usr/bin/env bash
set -euo pipefail

if [[ "$(uname -s)" != "Darwin" ]]; then
    echo "This installer is for macOS. On Windows, use install_windows.ps1." >&2
    exit 1
fi

EXTENSION_ID="${1:-ilgppibegoodogiadncbdeamojfhmolm}"
if [[ ! "$EXTENSION_ID" =~ ^[a-p]{32}$ ]]; then
    echo "Invalid extension ID. Copy the 32-character ID from chrome://extensions." >&2
    exit 1
fi

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
COMPANION_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"
BINARY_PATH="$COMPANION_DIR/target/release/ai-download-companion"
MANIFEST_DIR="$HOME/Library/Application Support/Google/Chrome/NativeMessagingHosts"
MANIFEST_PATH="$MANIFEST_DIR/com.ai.downloader.companion.json"

# Check alternative binary locations if target/release is missing
if [[ ! -f "$BINARY_PATH" ]]; then
    if [[ -f "$COMPANION_DIR/bin/ai-download-companion" ]]; then
        BINARY_PATH="$COMPANION_DIR/bin/ai-download-companion"
    elif [[ -f "$COMPANION_DIR/ai-download-companion" ]]; then
        BINARY_PATH="$COMPANION_DIR/ai-download-companion"
    fi
fi

# Ensure executable permissions and remove quarantine before checking -x
if [[ -f "$BINARY_PATH" ]]; then
    if command -v chmod >/dev/null 2>&1; then
        chmod +x "$BINARY_PATH" 2>/dev/null || true
    fi
    if command -v xattr >/dev/null 2>&1; then
        xattr -d com.apple.quarantine "$BINARY_PATH" 2>/dev/null || true
    fi
fi

if [[ ! -x "$BINARY_PATH" ]]; then
    if ! command -v cargo >/dev/null 2>&1; then
        echo "The companion binary is missing. Install Rust and Cargo, then retry." >&2
        exit 1
    fi
    echo "Building the companion for this Mac..."
    cargo build --release --locked --manifest-path "$COMPANION_DIR/Cargo.toml"
    if command -v chmod >/dev/null 2>&1; then
        chmod +x "$BINARY_PATH" 2>/dev/null || true
    fi
fi

FILE_INFO="$(file "$BINARY_PATH")"
if [[ "$FILE_INFO" != *"Mach-O"* ]]; then
    echo "The companion binary is not a macOS executable. Build it on this Mac." >&2
    exit 1
fi
ARCH="$(uname -m)"
if [[ "$FILE_INFO" != *"$ARCH"* ]]; then
    echo "The companion binary does not support this Mac's $ARCH architecture. Build it on this Mac." >&2
    exit 1
fi

json_string() {
    local LC_ALL=C
    local value="$1" char i
    printf '"'
    for ((i = 0; i < ${#value}; i++)); do
        char="${value:i:1}"
        case "$char" in
            '"') printf '\\"' ;;
            '\') printf '\\\\' ;;
            [[:cntrl:]]) printf '\\u%04x' "'$char" ;;
            *) printf '%s' "$char" ;;
        esac
    done
    printf '"'
}

mkdir -p "$MANIFEST_DIR"
{
    printf '{\n  "name": "com.ai.downloader.companion",\n'
    printf '  "description": "AI Download Accelerator High-Speed Rust Companion",\n'
    printf '  "path": '
    json_string "$BINARY_PATH"
    printf ',\n  "type": "stdio",\n  "allowed_origins": ['
    json_string "chrome-extension://$EXTENSION_ID/"
    printf ']\n}\n'
} > "$MANIFEST_PATH"

echo "Chrome native companion registered for extension $EXTENSION_ID."
echo "Reload the extension in chrome://extensions and open the popup."
