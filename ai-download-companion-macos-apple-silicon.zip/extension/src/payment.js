import { stripeTestPaymentLink } from './payment-config.js';

export function isStripeTestPaymentLink(value) {
  try {
    const url = new URL(value);
    return url.protocol === 'https:'
      && url.hostname === 'buy.stripe.com'
      && !url.port
      && !url.username
      && !url.password
      && /^\/test_[a-zA-Z0-9]+$/.test(url.pathname)
      && !url.search
      && !url.hash;
  } catch {
    return false;
  }
}

export function setupStripeTestCheckout(link, status, url) {
  link.hidden = true;
  link.removeAttribute('href');
  if (!url) {
    status.textContent = 'Test checkout is not configured. No payment is collected.';
    return;
  }
  if (!isStripeTestPaymentLink(url)) {
    status.textContent = 'Invalid Stripe test link. Test checkout is unavailable.';
    console.error('Stripe checkout configuration must be a Stripe test-mode Payment Link.');
    return;
  }
  link.href = url;
  link.hidden = false;
  status.textContent = 'Test mode only: no real payment or Pro access is provided.';
}

document.addEventListener('DOMContentLoaded', () => {
  setupStripeTestCheckout(
    document.getElementById('stripeTestCheckout'),
    document.getElementById('stripeCheckoutStatus'),
    stripeTestPaymentLink
  );
});
