export const FREE_MONTHLY_LIMIT = 5;

export function createUsageLimit(storage, now = () => new Date()) {
  let pending = Promise.resolve();

  function run(operation) {
    const result = pending.then(operation);
    pending = result.catch(() => {});
    return result;
  }

  async function read() {
    const month = now().toISOString().slice(0, 7);
    const { freeDownloadUsage } = await storage.get('freeDownloadUsage');
    if (freeDownloadUsage === undefined || freeDownloadUsage.month !== month) {
      return { month, count: 0 };
    }
    if (!Number.isSafeInteger(freeDownloadUsage.count) || freeDownloadUsage.count < 0) {
      throw new Error('Stored download allowance is invalid.');
    }
    return freeDownloadUsage;
  }

  return {
    status() {
      return run(async () => {
        const usage = await read();
        return { tier: 'free', count: usage.count, limit: FREE_MONTHLY_LIMIT, month: usage.month };
      });
    },
    start(operation) {
      return run(async () => {
        const usage = await read();
        if (usage.count >= FREE_MONTHLY_LIMIT) {
          return { success: false, error: 'Free limit reached: 5 accelerated downloads per UTC calendar month.' };
        }
        await storage.set({ freeDownloadUsage: { ...usage, count: usage.count + 1 } });
        try {
          const result = await operation();
          if (!result.success) {
            await storage.set({ freeDownloadUsage: usage });
          }
          return result;
        } catch (error) {
          await storage.set({ freeDownloadUsage: usage });
          throw error;
        }
      });
    }
  };
}
