/**
 * AI Strategy Heuristic Engine - Maximum Speed Edition
 *
 * Dynamically computes optimal parallel thread count, chunk size,
 * TCP socket parameters, and dynamic chunk stealing configurations.
 */

export class StrategyHeuristic {
  /**
   * Determine optimal download strategy with hyper-acceleration features.
   * @param {Object} metadata
   * @param {string} metadata.url
   * @param {number} [metadata.totalBytes]
   * @param {string} [metadata.mimeType]
   * @param {boolean} [metadata.acceptRanges]
   * @param {string} [metadata.mode] 'hyper_speed' | 'max_speed' | 'balanced' | 'bandwidth_saver'
   * @param {number} [metadata.latencyMs]
   * @param {number} [metadata.measuredBandwidthMbps]
   * @returns {Object} Strategy plan
   */
  static evaluate(metadata) {
    const {
      url,
      totalBytes = 0,
      mimeType = '',
      acceptRanges = true,
      mode = 'hyper_speed',
      latencyMs = 45,
      measuredBandwidthMbps = 100
    } = metadata;

    const reasons = [];
    let concurrency = 8;
    let chunkSize = 8 * 1024 * 1024; // 8MB default
    let pipeline = 'parallel_range';
    let shouldAccelerate = true;
    let enableChunkStealing = true;
    let tcpNoDelay = true;
    let preallocateDisk = true;
    let bufferPoolSizeKb = 256;

    // Detect media streaming formats (HLS / DASH)
    const isM3u8 = url.includes('.m3u8') || mimeType.includes('application/x-mpegURL');
    const isMpd = url.includes('.mpd') || mimeType.includes('application/dash+xml');
    if (isM3u8 || isMpd) {
      pipeline = 'media_stream';
      concurrency = 8;
      reasons.push('Detected adaptive media playlist (HLS/DASH). Switching to high-speed segment fetch pipeline.');
      return {
        shouldAccelerate: true,
        concurrency,
        chunkSize: 0,
        pipeline,
        enableChunkStealing: false,
        tcpNoDelay,
        preallocateDisk: false,
        reasons
      };
    }

    // Check if server refuses Range requests
    if (acceptRanges === false) {
      pipeline = 'direct_stream';
      concurrency = 1;
      enableChunkStealing = false;
      reasons.push('Server does not support HTTP Range requests (Accept-Ranges: none). Falling back to single-stream pipeline with optimized 512KB socket buffer.');
      return {
        shouldAccelerate: true,
        concurrency,
        chunkSize: 0,
        pipeline,
        enableChunkStealing,
        tcpNoDelay,
        preallocateDisk: false,
        reasons
      };
    }

    // Calculate Bandwidth-Delay Product (BDP) to scale socket buffer
    // BDP (bytes) = Bandwidth (bytes/sec) * RTT (sec)
    const rttSec = Math.max(0.01, latencyMs / 1000);
    const bdpBytes = (measuredBandwidthMbps * 1000 * 1000 / 8) * rttSec;
    bufferPoolSizeKb = Math.min(2048, Math.max(128, Math.round(bdpBytes / 1024 / concurrency)));

    // File Size Tiering and Concurrency Calculation
    if (totalBytes > 0) {
      const mb = totalBytes / (1024 * 1024);

      if (mb < 2) {
        // Very small files (<2MB)
        concurrency = 1;
        chunkSize = totalBytes;
        enableChunkStealing = false;
        reasons.push(`Tiny payload (${mb.toFixed(1)}MB): single persistent HTTP/2 connection avoids handshake overhead.`);
      } else if (mb < 25) {
        // Small files (2MB - 25MB)
        concurrency = mode === 'hyper_speed' ? 6 : (mode === 'max_speed' ? 4 : 2);
        chunkSize = Math.max(1024 * 1024, Math.floor(totalBytes / concurrency));
        reasons.push(`Small file (${mb.toFixed(1)}MB): ${concurrency} connections with ${Math.round(chunkSize / (1024*1024))}MB chunks.`);
      } else if (mb < 250) {
        // Medium files (25MB - 250MB)
        concurrency = mode === 'hyper_speed' ? 16 : (mode === 'max_speed' ? 8 : 4);
        chunkSize = 8 * 1024 * 1024;
        reasons.push(`Medium file (${mb.toFixed(1)}MB): ${concurrency} parallel streams with chunk stealing enabled.`);
      } else if (mb < 2048) {
        // Large files (250MB - 2GB)
        concurrency = mode === 'hyper_speed' ? 24 : (mode === 'max_speed' ? 12 : 6);
        chunkSize = 16 * 1024 * 1024;
        reasons.push(`Large file (${(mb/1024).toFixed(2)}GB): ${concurrency} connections saturated across parallel TCP sockets.`);
      } else {
        // Massive files (>2GB) - Hyperdrive mode
        concurrency = mode === 'hyper_speed' ? 32 : (mode === 'max_speed' ? 16 : 8);
        chunkSize = 32 * 1024 * 1024;
        reasons.push(`Massive file (${(mb/1024).toFixed(2)}GB): Hyper-speed mode with ${concurrency} connections & zero-copy sparse disk allocation.`);
      }
    } else {
      // Unknown content length (dynamic streaming or chunked)
      concurrency = mode === 'hyper_speed' ? 12 : 6;
      chunkSize = 8 * 1024 * 1024;
      reasons.push('Content-Length omitted: dynamically probing initial 1MB range to test server byte-split support.');
    }

    // High Latency compensation (Cross-continental / overseas servers)
    if (latencyMs > 120) {
      concurrency = Math.min(32, concurrency + 4);
      reasons.push(`High RTT (${latencyMs}ms): added +4 connections to maximize TCP congestion window filling.`);
    }

    // Dynamic Chunk Stealing Strategy
    if (enableChunkStealing) {
      reasons.push('AI Dynamic Chunk Stealing: idle worker threads will dynamically steal and bisect remaining ranges from lagging connections.');
    }

    return {
      shouldAccelerate,
      concurrency,
      chunkSize,
      pipeline,
      enableChunkStealing,
      tcpNoDelay,
      preallocateDisk,
      bufferPoolSizeKb,
      reasons
    };
  }
}
