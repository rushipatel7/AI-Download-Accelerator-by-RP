/**
 * AI Download Accelerator - Content Script Link Interceptor
 * Listens for user clicks on downloadable links in webpages and routes them
 * to the high-speed multi-connection accelerator.
 */

const DOWNLOAD_EXTENSIONS = new Set([
  'zip', 'rar', '7z', 'tar', 'gz', 'bz2', 'xz',
  'iso', 'dmg', 'pkg', 'exe', 'msi', 'apk', 'bin',
  'mp4', 'mkv', 'avi', 'mov', 'webm', 'flv',
  'mp3', 'wav', 'flac', 'aac', 'ogg',
  'pdf', 'epub', 'mobi',
  'csv', 'xlsx', 'docx', 'pptx',
  'torrent'
]);

let autoInterceptEnabled = true;
let companionConnected = false;
chrome.runtime.sendMessage({ type: 'GET_STATUS' }, (response) => {
  if (chrome.runtime.lastError) {
    console.warn('Could not check companion status:', chrome.runtime.lastError.message);
    return;
  }
  companionConnected = response?.isConnected === true;
});

chrome.runtime.onMessage.addListener((message) => {
  if (message.type === 'STATUS_UPDATE') {
    companionConnected = message.isConnected === true;
  }
});

chrome.storage.local.get(['settings'], (res) => {
  autoInterceptEnabled = res.settings?.autoIntercept !== false;
});

chrome.storage.onChanged.addListener((changes, areaName) => {
  if (areaName === 'local' && changes.settings) {
    autoInterceptEnabled = changes.settings.newValue?.autoIntercept !== false;
  }
});

document.addEventListener('click', (e) => {
  if (!autoInterceptEnabled || !companionConnected) return;

  const target = e.target instanceof Element ? e.target : e.target.parentElement;
  if (!target) return;

  const downloadButton = target.closest('[data-download-url]');
  if (downloadButton) {
    chrome.runtime.sendMessage({
      type: 'BYPASS_AUTO_INTERCEPT',
      url: new URL(downloadButton.getAttribute('data-download-url'), window.location.href).href
    });
    return;
  }

  const link = target.closest('a');
  if (!link || !link.href) return;

  const url = link.href;

  // Skip non-http URLs and page hash anchors
  if (!url.startsWith('http://') && !url.startsWith('https://')) return;
  if (url.startsWith(window.location.href + '#')) return;

  // Check if link has explicit download attribute
  const hasDownloadAttr = link.hasAttribute('download');

  // Check file extension
  let isDownloadableExt = false;
  let filename = link.getAttribute('download') || '';

  try {
    const parsed = new URL(url);
    const pathname = parsed.pathname;
    const parts = pathname.split('/').filter(Boolean);
    if (parts.length > 0) {
      const lastPart = parts[parts.length - 1];
      const dotIdx = lastPart.lastIndexOf('.');
      if (dotIdx !== -1) {
        const ext = lastPart.substring(dotIdx + 1).toLowerCase();
        if (DOWNLOAD_EXTENSIONS.has(ext)) {
          isDownloadableExt = true;
          if (!filename) filename = decodeURIComponent(lastPart);
        }
      }
    }
  } catch (_) {}

  if (hasDownloadAttr || isDownloadableExt) {
    // Intercept click and hand off to AI Accelerator
    e.preventDefault();
    e.stopPropagation();

    chrome.runtime.sendMessage({
      type: 'TRIGGER_DOWNLOAD',
      url: url,
      meta: {
        filename: filename,
        referer: window.location.href,
        source: 'content_click'
      }
    }, (response) => {
      if (!chrome.runtime.lastError && response?.success) {
        showNotificationToast(filename || 'File');
        return;
      }
      const error = chrome.runtime.lastError?.message || response?.error || 'Download could not start.';
      console.warn('Accelerated download unavailable:', error);
      chrome.runtime.sendMessage({ type: 'FALLBACK_BROWSER_DOWNLOAD', url }, (fallback) => {
        if (chrome.runtime.lastError || !fallback?.success) {
          console.error('Browser download fallback failed:', chrome.runtime.lastError?.message || fallback?.error);
          window.location.href = url;
          return;
        }
        showNotificationToast(error, true);
      });
    });
  }
}, true);

/**
 * Show a sleek floating toast notification in the webpage
 */
function showNotificationToast(filename, fallback = false) {
  const existing = document.getElementById('ai-downloader-toast');
  if (existing) existing.remove();

  const toast = document.createElement('div');
  toast.id = 'ai-downloader-toast';
  const panel = document.createElement('div');
  panel.style.cssText = `
    position: fixed; bottom: 24px; right: 24px;
    background: rgba(15, 23, 42, 0.95); border: 1px solid #38bdf8;
    box-shadow: 0 10px 25px -5px rgba(56, 189, 248, 0.4);
    color: #f8fafc; padding: 12px 18px; border-radius: 12px;
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
    font-size: 13px; display: flex; align-items: center; gap: 10px;
    z-index: 2147483647; backdrop-filter: blur(8px); transition: all 0.3s ease;
  `;
  const icon = document.createElement('span');
  icon.style.fontSize = '18px';
  icon.textContent = '⚡';
  const details = document.createElement('div');
  const title = document.createElement('div');
  title.style.cssText = 'font-weight: 700; color: #38bdf8; font-size: 13px;';
  title.textContent = fallback ? 'Using browser download' : 'AI Accelerator Active';
  const filenameText = document.createElement('div');
  filenameText.style.cssText = 'font-size: 11px; color: #94a3b8; max-width: 260px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;';
  filenameText.textContent = fallback ? filename : `Accelerating: ${filename}`;
  details.append(title, filenameText);
  panel.append(icon, details);
  toast.appendChild(panel);

  document.body.appendChild(toast);
  setTimeout(() => {
    panel.style.opacity = '0';
    panel.style.transform = 'translateY(10px)';
    setTimeout(() => toast.remove(), 300);
  }, 2500);
}
