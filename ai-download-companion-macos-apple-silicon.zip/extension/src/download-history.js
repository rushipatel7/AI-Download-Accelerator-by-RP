const INTERRUPTED = new Set(['starting', 'downloading', 'paused']);

export async function restoreDownloadHistory(storage, downloads) {
  const saved = await storage.get(['downloads']);
  if (saved.downloads !== undefined && !Array.isArray(saved.downloads)) {
    throw new Error('Stored download history is invalid.');
  }
  for (const entry of saved.downloads || []) {
    if (!entry || typeof entry.id !== 'string') {
      console.warn('Skipping invalid download history entry.');
      continue;
    }
    const item = { ...entry };
    if (INTERRUPTED.has(item.status)) {
      item.status = 'interrupted';
      item.error = 'The companion connection ended. This download cannot be resumed after a restart yet.';
      item.speedBytesPerSec = 0;
    }
    downloads.set(item.id, item);
  }
}

export function createHistoryWriter(storage, downloads) {
  let pending = Promise.resolve();
  return () => {
    const entries = Array.from(downloads.values());
    const active = entries.filter(item => INTERRUPTED.has(item.status));
    const recent = entries.filter(item => !INTERRUPTED.has(item.status)).slice(-100);
    const snapshot = [...recent, ...active].map(item => ({ ...item }));
    pending = pending.catch(() => {}).then(() => storage.set({ downloads: snapshot }));
    return pending;
  };
}
