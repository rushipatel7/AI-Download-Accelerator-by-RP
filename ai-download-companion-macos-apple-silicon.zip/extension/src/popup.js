/**
 * AI Download Accelerator - Popup UI Logic
 * Supports Single URL, Multi-URL Batch Sets, and Live Companion Link Diagnostics.
 */

document.addEventListener('DOMContentLoaded', () => {
  const urlInput = document.getElementById('urlInput');
  const startBtn = document.getElementById('startBtn');
  const downloadsList = document.getElementById('downloadsList');
  const activeCount = document.getElementById('activeCount');
  const globalSpeed = document.getElementById('globalSpeed');
  const activeStreams = document.getElementById('activeStreams');
  const setCount = document.getElementById('setCount');
  const pills = document.querySelectorAll('.pill');
  const historySearch = document.getElementById('historySearch');
  const historyFilter = document.getElementById('historyFilter');
  const freeUsage = document.getElementById('freeUsage');
  const singleError = document.getElementById('singleError');
  document.getElementById('extensionVersion').textContent = `v${chrome.runtime.getManifest().version}`;
  let latestDownloads = [];

  historySearch.addEventListener('input', () => renderDownloads(latestDownloads));
  historyFilter.addEventListener('change', () => renderDownloads(latestDownloads));

  function refreshUsage() {
    chrome.runtime.sendMessage({ type: 'GET_USAGE' }, (response) => {
      if (chrome.runtime.lastError || !response || response.success === false) {
        freeUsage.textContent = 'Could not load the free allowance.';
        return;
      }
      freeUsage.textContent = `${response.count} / ${response.limit} starts used in ${response.month} (UTC).`;
    });
  }

  // Companion status elements
  const companionStatus = document.getElementById('companionStatus');
  const statusText = document.getElementById('statusText');
  const companionAlert = document.getElementById('companionAlert');
  const extensionIdDisplay = document.getElementById('extensionIdDisplay');
  const copyIdBtn = document.getElementById('copyIdBtn');
  const companionError = document.getElementById('companionError');

  // Tab elements
  const tabSingle = document.getElementById('tabSingle');
  const tabSet = document.getElementById('tabSet');
  const singleInputView = document.getElementById('singleInputView');
  const batchSetView = document.getElementById('batchSetView');
  const batchUrlsInput = document.getElementById('batchUrlsInput');
  const batchError = document.getElementById('batchError');
  const startBatchBtn = document.getElementById('startBatchBtn');
  const loadPresetSetBtn = document.getElementById('loadPresetSetBtn');
  const clearBatchInputBtn = document.getElementById('clearBatchInputBtn');
  const clearCompletedBtn = document.getElementById('clearCompletedBtn');

  downloadsList.addEventListener('click', (event) => {
    const button = event.target.closest('button[data-download-action]');
    if (!button) return;

    chrome.runtime.sendMessage({
      type: button.dataset.downloadAction,
      id: button.dataset.downloadId
    }, (response) => {
      if (chrome.runtime.lastError) {
        console.error('Download control failed:', chrome.runtime.lastError.message);
        return;
      }
      if (response?.success === false) {
        console.error('Download control failed:', response.error);
        button.title = response.error || 'Unable to control download';
      }
      refreshDownloads();
    });
  });

  let currentExtId = chrome.runtime.id;

  function displayCompanionStatus(res) {
    if (!res) return;
    currentExtId = res.extensionId || chrome.runtime.id;
    if (extensionIdDisplay) extensionIdDisplay.textContent = currentExtId;
    if (companionError) companionError.textContent = res.lastError || res.error || '';

    if (res.isConnected) {
      companionStatus.className = 'status-badge';
      statusText.textContent = 'Companion: Ready';
      if (companionAlert) companionAlert.style.display = 'none';
    } else {
      companionStatus.className = 'status-badge offline';
      statusText.textContent = 'Companion: Needs Setup';
      if (companionAlert) companionAlert.style.display = 'flex';
    }
  }

  function checkCompanionStatus() {
    chrome.runtime.sendMessage({ type: 'GET_STATUS' }, displayCompanionStatus);
  }

  // Copy Extension ID button
  if (copyIdBtn) {
    copyIdBtn.addEventListener('click', () => {
      navigator.clipboard.writeText(currentExtId).then(() => {
        const orig = copyIdBtn.textContent;
        copyIdBtn.textContent = 'Copied!';
        setTimeout(() => { copyIdBtn.textContent = orig; }, 2000);
      });
    });
  }

  // Tab switching
  tabSingle.addEventListener('click', () => {
    tabSingle.classList.add('active');
    tabSet.classList.remove('active');
    singleInputView.style.display = 'flex';
    batchSetView.style.display = 'none';
  });

  tabSet.addEventListener('click', () => {
    tabSet.classList.add('active');
    tabSingle.classList.remove('active');
    singleInputView.style.display = 'none';
    batchSetView.style.display = 'flex';
  });

  // Load Preset Test Set
  loadPresetSetBtn.addEventListener('click', () => {
    batchUrlsInput.value = [
      'https://proof.ovh.net/files/10Mb.dat',
      'https://proof.ovh.net/files/100Mb.dat',
      'http://speedtest.tele2.net/100MB.zip'
    ].join('\n');
  });

  clearBatchInputBtn.addEventListener('click', () => {
    batchUrlsInput.value = '';
    batchError.textContent = '';
  });

  // Start Batch Download Set
  startBatchBtn.addEventListener('click', () => {
    const lines = batchUrlsInput.value.split('\n').map((value, index) => ({ value: value.trim(), line: index + 1 })).filter(entry => entry.value);
    if (!lines.length) {
      batchError.textContent = 'Enter at least one HTTP or HTTPS URL.';
      return;
    }
    const invalid = lines.filter(({ value }) => {
      try {
        const url = new URL(value);
        return !['http:', 'https:'].includes(url.protocol);
      } catch {
        return true;
      }
    });
    if (invalid.length) {
      batchError.textContent = `Invalid HTTP or HTTPS URL on line${invalid.length === 1 ? '' : 's'}: ${invalid.map(entry => entry.line).join(', ')}.`;
      return;
    }
    batchError.textContent = '';
    startBatchBtn.disabled = true;
    chrome.runtime.sendMessage({ type: 'TRIGGER_BATCH_DOWNLOAD', urls: lines.map(entry => entry.value) }, (response) => {
      startBatchBtn.disabled = false;
      if (chrome.runtime.lastError || !response?.success) {
        batchError.textContent = chrome.runtime.lastError?.message || response?.error || 'Could not start the download set.';
        if (Array.isArray(response?.remainingUrls)) batchUrlsInput.value = response.remainingUrls.join('\n');
      } else {
        batchUrlsInput.value = '';
        tabSingle.click();
      }
      refreshDownloads();
    });
  });

  // Clear Completed & Stalled items
  clearCompletedBtn.addEventListener('click', () => {
    chrome.runtime.sendMessage({ type: 'CLEAR_COMPLETED' }, () => {
      refreshDownloads();
    });
  });

  const autoInterceptToggle = document.getElementById('autoInterceptToggle');

  // Load settings & active downloads
  chrome.storage.local.get(['settings', 'downloads'], (data) => {
    const mode = data.settings?.mode || 'hyper_speed';
    const isAuto = data.settings?.autoIntercept !== false;
    if (autoInterceptToggle) autoInterceptToggle.checked = isAuto;

    pills.forEach((p) => {
      p.classList.toggle('active', p.dataset.mode === mode);
    });
    renderDownloads(data.downloads || []);
  });

  // Toggle auto-intercept
  if (autoInterceptToggle) {
    autoInterceptToggle.addEventListener('change', () => {
      chrome.storage.local.get(['settings'], (res) => {
        const settings = res.settings || {};
        settings.autoIntercept = autoInterceptToggle.checked;
        chrome.storage.local.set({ settings });
      });
    });
  }

  // Switch speed mode
  pills.forEach((pill) => {
    pill.addEventListener('click', () => {
      pills.forEach((p) => p.classList.remove('active'));
      pill.classList.add('active');
      const mode = pill.dataset.mode;
      chrome.storage.local.get(['settings'], (res) => {
        const settings = res.settings || {};
        settings.mode = mode;
        chrome.storage.local.set({ settings });
      });
    });
  });

  // Quick single download
  startBtn.addEventListener('click', () => {
    const url = urlInput.value.trim();
    if (!url) {
      singleError.textContent = 'Enter a download URL.';
      return;
    }
    startBtn.disabled = true;
    chrome.runtime.sendMessage({ type: 'TRIGGER_DOWNLOAD', url }, (response) => {
      startBtn.disabled = false;
      if (chrome.runtime.lastError || !response?.success) {
        singleError.textContent = chrome.runtime.lastError?.message || response?.error || 'Could not start download.';
      } else {
        singleError.textContent = '';
        urlInput.value = '';
      }
      refreshUsage();
      refreshDownloads();
    });
  });

  // Listen for live updates from background worker
  chrome.runtime.onMessage.addListener((msg) => {
    if (msg.type === 'DOWNLOAD_PROGRESS' || msg.type === 'DOWNLOAD_COMPLETED' || msg.type === 'DOWNLOAD_FAILED' || msg.type === 'STATUS_UPDATE' || msg.type === 'BASELINE_RECORDED') {
      refreshDownloads();
      if (msg.type === 'STATUS_UPDATE') displayCompanionStatus(msg);
    }
  });

  function refreshDownloads() {
    chrome.runtime.sendMessage({ type: 'GET_ACTIVE_DOWNLOADS' }, (res) => {
      if (res && res.downloads) {
        renderDownloads(res.downloads);
      }
    });
  }

  function renderDownloads(items) {
    latestDownloads = items || [];
    if (!items || items.length === 0) {
      downloadsList.innerHTML = '<div class="empty-state">No active downloads. Paste a single link or add a Download Set above!</div>';
      activeCount.textContent = '0';
      globalSpeed.innerHTML = '0.0 <small>MB/s</small>';
      activeStreams.textContent = '0';
      if (setCount) setCount.textContent = '0';
      return;
    }

    const activeList = items.filter(i => i.status === 'downloading' || i.status === 'starting');
    activeCount.textContent = items.length;
    if (setCount) setCount.textContent = activeList.length.toString();

    let totalSpeedBytes = 0;
    let totalStreams = 0;

    const query = historySearch.value.trim().toLowerCase();
    const filter = historyFilter.value || 'all';
    const matches = items.filter(item => {
      const searchable = `${item.filename || ''} ${item.url || ''}`.toLowerCase();
      const statusMatches = filter === 'all'
        || (filter === 'active' && ['starting', 'downloading', 'paused'].includes(item.status))
        || (filter === 'completed' && item.status === 'completed')
        || (filter === 'failed' && ['failed', 'interrupted', 'companion_offline'].includes(item.status));
      return searchable.includes(query) && statusMatches;
    });

    downloadsList.innerHTML = '';
    items.forEach(item => {
      if (item.status === 'downloading') {
        totalSpeedBytes += item.speedBytesPerSec || 0;
        totalStreams += item.activeConnections || item.concurrency || 1;
      }
    });
    if (!matches.length) {
      downloadsList.innerHTML = '<div class="empty-state">No downloads match your search or filter.</div>';
    }
    matches.slice().reverse().forEach((item) => {

      const card = document.createElement('div');
      card.className = 'dl-card';

      const progressPercent = item.totalBytes > 0 
        ? Math.min(100, (item.downloadedBytes / item.totalBytes) * 100).toFixed(1) 
        : 0;

      const speedMb = ((item.speedBytesPerSec || 0) / (1024 * 1024)).toFixed(2);
      const downloadedMb = ((item.downloadedBytes || 0) / (1024 * 1024)).toFixed(1);
      const totalMb = item.totalBytes > 0 ? ((item.totalBytes) / (1024 * 1024)).toFixed(1) + 'MB' : 'Unknown';

      // Build chunk visualization segments
      const chunkCount = item.concurrency || 8;
      let chunkSegmentsHtml = '';
      for (let i = 0; i < chunkCount; i++) {
        const chunkRatio = (item.downloadedBytes / (item.totalBytes || 1));
        const isDone = (i + 1) / chunkCount <= chunkRatio;
        const isActive = !isDone && (i / chunkCount <= chunkRatio);
        const cls = isDone ? 'done' : (isActive ? 'active' : '');
        chunkSegmentsHtml += `<div class="chunk-segment ${cls}" style="flex: 1;"></div>`;
      }

      const displayStatus = item.status === 'companion_offline' ? 'Setup Needed' : item.status;
      const statusClass = ['starting', 'downloading', 'paused', 'completed', 'failed'].includes(item.status)
        ? item.status
        : 'failed';
      const durationText = item.durationMs > 0
        ? `Extension: ${formatDuration(item.durationMs)}${item.normalDurationMs ? ` • Chrome: ${formatDuration(item.normalDurationMs)}` : ''}`
        : '';
      const comparisonText = Number.isFinite(item.timeSavedPercent)
        ? item.timeSavedPercent >= 0
          ? `${item.timeSavedPercent.toFixed(1)}% time saved vs Chrome`
          : `${Math.abs(item.timeSavedPercent).toFixed(1)}% slower than Chrome`
        : '';

      const header = document.createElement('div');
      header.className = 'dl-card-header';
      const filename = document.createElement('div');
      filename.className = 'dl-filename';
      filename.textContent = item.filename || 'Download';
      filename.title = filename.textContent;
      const statusBadge = document.createElement('span');
      statusBadge.className = `dl-status-badge ${statusClass}`;
      statusBadge.textContent = displayStatus;
      header.append(filename, statusBadge);
      card.appendChild(header);

      if (['starting', 'downloading', 'paused'].includes(item.status)) {
        const controls = document.createElement('div');
        controls.className = 'dl-controls';
        const actionButton = (action, label, extraClass = '') => {
          const button = document.createElement('button');
          button.className = `btn-download-control ${extraClass}`.trim();
          button.dataset.downloadAction = action;
          button.dataset.downloadId = item.id;
          button.title = action === 'CANCEL_DOWNLOAD' ? 'Stop and discard download' : `${label} download`;
          button.textContent = label;
          return button;
        };
        controls.appendChild(item.status === 'paused'
          ? actionButton('RESUME_DOWNLOAD', 'Resume')
          : actionButton('PAUSE_DOWNLOAD', 'Pause'));
        controls.appendChild(actionButton('CANCEL_DOWNLOAD', 'Stop', 'stop'));
        card.appendChild(controls);
      }

      const chunkBar = document.createElement('div');
      chunkBar.className = 'chunk-bar-container';
      chunkBar.innerHTML = chunkSegmentsHtml;
      card.appendChild(chunkBar);

      const metadata = document.createElement('div');
      metadata.className = 'dl-meta';
      const transferProgress = document.createElement('span');
      transferProgress.textContent = `${downloadedMb}MB / ${totalMb} (${progressPercent}%)`;
      const streams = document.createElement('span');
      streams.className = 'ai-pill';
      streams.textContent = `⚡ ${item.concurrency || 1} streams • Stealing`;
      const speed = document.createElement('span');
      speed.textContent = item.status === 'downloading' ? `${speedMb} MB/s` : '';
      metadata.append(transferProgress, streams, speed);
      card.appendChild(metadata);

      if (durationText) {
        const timing = document.createElement('div');
        timing.className = 'dl-meta';
        const duration = document.createElement('span');
        duration.textContent = durationText;
        timing.appendChild(duration);
        if (comparisonText) {
          const comparison = document.createElement('span');
          comparison.className = 'ai-pill';
          comparison.textContent = comparisonText;
          timing.appendChild(comparison);
        }
        card.appendChild(timing);
      }
      if (item.error) {
        const errorMessage = document.createElement('div');
        errorMessage.className = 'dl-error-message';
        errorMessage.textContent = item.error;
        card.appendChild(errorMessage);
      }
      downloadsList.appendChild(card);
    });

    const globalMb = (totalSpeedBytes / (1024 * 1024)).toFixed(1);
    globalSpeed.innerHTML = `${globalMb} <small>MB/s</small>`;
    activeStreams.textContent = totalStreams.toString();
  }

  function formatDuration(durationMs) {
    const totalSeconds = Math.round(durationMs / 1000);
    const hours = Math.floor(totalSeconds / 3600);
    const minutes = Math.floor((totalSeconds % 3600) / 60);
    const seconds = totalSeconds % 60;

    if (hours > 0) return `${hours}h ${minutes}m ${seconds}s`;
    if (minutes > 0) return `${minutes}m ${seconds}s`;
    return `${seconds}s`;
  }

  // Initial checks
  checkCompanionStatus();
  refreshUsage();
  setInterval(refreshDownloads, 1000);
  setInterval(() => {
    checkCompanionStatus();
    refreshUsage();
  }, 3000);
});
