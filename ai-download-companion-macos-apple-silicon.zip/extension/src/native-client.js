/**
 * Native Messaging Host Client Bridge
 * Communicates with the local high-speed Rust companion daemon.
 */

export class NativeCompanionClient {
  constructor(hostName = 'com.ai.downloader.companion') {
    this.hostName = hostName;
    this.port = null;
    this.listeners = new Map();
    this.isConnected = false;
    this.lastError = null;
    this.handshakeTimer = null;
  }

  connect() {
    if (this.port) return;

    try {
      this.port = chrome.runtime.connectNative(this.hostName);
      this.lastError = null;

      this.port.onMessage.addListener((message) => {
        if (message.type === 'stats' && !this.isConnected) {
          clearTimeout(this.handshakeTimer);
          this.handshakeTimer = null;
          this.isConnected = true;
          this.emit('connect', { host: this.hostName });
        }
        this.emit(message.type || 'message', message);
      });

      this.port.onDisconnect.addListener(() => {
        const err = chrome.runtime.lastError?.message || 'Disconnected from Native Companion';
        clearTimeout(this.handshakeTimer);
        this.handshakeTimer = null;
        this.isConnected = false;
        this.port = null;
        this.lastError = this.lastError || err;
        this.emit('disconnect', { error: this.lastError });
      });

      this.handshakeTimer = setTimeout(() => {
        this.lastError = 'Native companion did not respond to the connection check.';
        this.port?.disconnect();
      }, 5000);
      this.port.postMessage({ command: 'GET_STATS' });
    } catch (e) {
      clearTimeout(this.handshakeTimer);
      this.handshakeTimer = null;
      this.isConnected = false;
      if (this.port) this.port.disconnect();
      this.port = null;
      this.lastError = e.message;
      this.emit('error', { error: e.message });
    }
  }

  send(message) {
    if (!this.isConnected || !this.port) {
      this.connect();
    }
    if (this.port) {
      this.port.postMessage(message);
    } else {
      throw new Error('Native Companion not available');
    }
  }

  on(event, handler) {
    if (!this.listeners.has(event)) {
      this.listeners.set(event, new Set());
    }
    this.listeners.get(event).add(handler);
    return () => this.off(event, handler);
  }

  off(event, handler) {
    if (this.listeners.has(event)) {
      this.listeners.get(event).delete(handler);
    }
  }

  emit(event, data) {
    if (this.listeners.has(event)) {
      for (const handler of this.listeners.get(event)) {
        try {
          handler(data);
        } catch (err) {
          console.error(`Error in event listener for ${event}:`, err);
        }
      }
    }
  }
}
