/**
 * AI Download Accelerator - Background Service Worker
 * Orchestrates download monitoring, AI heuristic strategy decision,
 * native companion delegation, and popup telemetry.
 */

import { StrategyHeuristic } from './heuristic.js';
import { NativeCompanionClient } from './native-client.js';
import { createHistoryWriter, restoreDownloadHistory } from './download-history.js';
import { createUsageLimit } from './usage-limit.js';

const nativeClient = new NativeCompanionClient();
const activeDownloads = new Map();
const temporarilyBypassedUrls = new Map();
const usageLimit = createUsageLimit(chrome.storage.local);
const historyReady = restoreDownloadHistory(chrome.storage.local, activeDownloads);
const writeHistory = createHistoryWriter(chrome.storage.local, activeDownloads);
historyReady.catch(error => console.error('[AI Downloader] Could not restore download history:', error));

// Initialize context menus
chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.create({
    id: 'ai-download-accelerator-link',
    title: '⚡ Accelerate Download with AI',
    contexts: ['link', 'image', 'video', 'audio']
  });

  chrome.contextMenus.create({
    id: 'ai-download-accelerator-page',
    title: '⚡ Scan & Accelerate Media on Page',
    contexts: ['page']
  });

  // Default configuration
  chrome.storage.local.get(['settings'], (res) => {
    if (!res.settings) {
      chrome.storage.local.set({
        settings: {
          mode: 'hyper_speed', // 'hyper_speed' | 'max_speed' | 'balanced'
          autoIntercept: true,
          minFileSizeMb: 5,
          defaultDestination: 'Downloads/Accelerated'
        }
      });
    }
  });
});

// Connect to native companion
nativeClient.connect();

nativeClient.on('connect', () => {
  console.log('[AI Downloader] Native Companion connected successfully.');
  broadcastCompanionStatus({ type: 'STATUS_UPDATE', isConnected: true });
});

nativeClient.on('disconnect', async (e) => {
  console.warn('[AI Downloader] Native companion disconnected:', e.error);
  try {
    await historyReady;
  } catch (error) {
    console.error('[AI Downloader] Could not update download history:', error);
    broadcastCompanionStatus({ type: 'STATUS_UPDATE', isConnected: false, error: e.error });
    return;
  }
  for (const [id, item] of activeDownloads.entries()) {
    if (['starting', 'downloading', 'paused'].includes(item.status)) {
      item.status = 'interrupted';
      item.error = 'Companion disconnected. Resuming interrupted downloads is not yet supported.';
      item.speedBytesPerSec = 0;
    }
  }
  persistDownloadState();
  broadcastCompanionStatus({ type: 'STATUS_UPDATE', isConnected: false, error: e.error });
});

nativeClient.on('progress', (msg) => {
  const item = activeDownloads.get(msg.id);
  if (item) {
    item.downloadedBytes = msg.downloadedBytes;
    item.totalBytes = msg.totalBytes;
    item.speedBytesPerSec = msg.speedBytesPerSec;
    item.activeConnections = msg.activeConnections;
    item.chunkProgress = msg.chunks || [];
    if (item.status !== 'paused') item.status = 'downloading';
    persistDownloadState();
    broadcastToPopup({ type: 'DOWNLOAD_PROGRESS', item });
  }
});

nativeClient.on('completed', (msg) => {
  const item = activeDownloads.get(msg.id);
  if (item) {
    if (msg.filename) item.filename = msg.filename;
    item.status = 'completed';
    item.completedAt = Date.now();
    item.durationMs = item.completedAt - item.createdAt;

    chrome.storage.local.get(['normalDownloadBaselines'], (res) => {
      const baselines = Array.isArray(res.normalDownloadBaselines)
        ? res.normalDownloadBaselines
        : [];
      const baseline = baselines.find((entry) =>
        entry.url === item.url ||
        entry.finalUrl === item.url ||
        entry.url === item.finalUrl
      ) || baselines.find((entry) =>
        entry.filename === item.filename &&
        entry.fileSize > 0 &&
        entry.fileSize === item.totalBytes
      );

      if (baseline && baseline.durationMs > 0) {
        item.normalDurationMs = baseline.durationMs;
        item.timeSavedPercent = ((baseline.durationMs - item.durationMs) / baseline.durationMs) * 100;
      }

      persistDownloadState();
      broadcastToPopup({ type: 'DOWNLOAD_COMPLETED', item });
    });

    chrome.notifications.create({
      type: 'basic',
      iconUrl: chrome.runtime.getURL('icons/icon-128.png'),
      title: 'Download Complete (AI Accelerated)',
      message: `${item.filename || 'File'} downloaded at peak speed!`
    });
  }
});

nativeClient.on('error', (msg) => {
  const item = activeDownloads.get(msg.id);
  if (item) {
    item.status = 'failed';
    item.error = msg.error;
    persistDownloadState();
    broadcastToPopup({ type: 'DOWNLOAD_FAILED', item });
  }
});

// Handle Context Menu Actions
chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  let targetUrl = info.srcUrl || info.linkUrl;
  if (!targetUrl && info.menuItemId === 'ai-download-accelerator-page') {
    targetUrl = tab.url;
  }
  if (targetUrl) {
    try {
      const result = await startAcceleratedDownload(targetUrl, { source: 'context_menu', tabUrl: tab?.url });
      if (!result.success) {
        chrome.notifications.create({
          type: 'basic', iconUrl: chrome.runtime.getURL('icons/icon-128.png'),
          title: 'Download not started', message: result.error
        });
      }
    } catch (error) {
      console.error('Context menu download failed:', error);
      chrome.notifications.create({
        type: 'basic', iconUrl: chrome.runtime.getURL('icons/icon-128.png'),
        title: 'Download not started', message: error.message
      });
    }
  }
});

// Deduplication cache to prevent double-intercepting from both click & download API
const recentIntercepts = new Map();
function shouldInterceptUrl(url) {
  const now = Date.now();
  if (recentIntercepts.has(url)) {
    if (now - recentIntercepts.get(url) < 2500) {
      return false;
    }
  }
  recentIntercepts.set(url, now);
  if (recentIntercepts.size > 100) {
    for (const [k, t] of recentIntercepts.entries()) {
      if (now - t > 10000) recentIntercepts.delete(k);
    }
  }
  return true;
}

function isTemporarilyBypassed(url) {
  const expiresAt = temporarilyBypassedUrls.get(url);
  if (!expiresAt) return false;
  if (expiresAt > Date.now()) return true;
  temporarilyBypassedUrls.delete(url);
  return false;
}

chrome.downloads.onCreated.addListener(async (downloadItem) => {
  if (downloadItem.byExtensionId === chrome.runtime.id) return;
  if (downloadItem.url.startsWith('blob:') || downloadItem.url.startsWith('data:')) return;

  const { settings } = await chrome.storage.local.get(['settings']);
  const autoIntercept = settings?.autoIntercept !== false;
  if (!autoIntercept || !nativeClient.isConnected) return;

  const targetUrl = downloadItem.url;
  if (isTemporarilyBypassed(targetUrl)) return;
  if (!shouldInterceptUrl(targetUrl)) return;

  try {
    const result = await startAcceleratedDownload(targetUrl, {
      filename: downloadItem.filename,
      totalBytes: downloadItem.totalBytes,
      mimeType: downloadItem.mime,
      referer: downloadItem.referrer
    });
    if (!result.success) {
      console.warn('Using Chrome download:', result.error);
      return;
    }
    await chrome.downloads.cancel(downloadItem.id);
    await chrome.downloads.erase({ id: downloadItem.id });
  } catch (err) {
    console.error('Failed to intercept onCreated:', err);
  }
});

// Record ordinary Chrome download durations while auto-interception is disabled.
chrome.downloads.onChanged.addListener((delta) => {
  if (delta.state?.current !== 'complete') return;

  chrome.downloads.search({ id: delta.id }, (items) => {
    const item = items?.[0];
    if (!item || item.byExtensionId === chrome.runtime.id) return;

    chrome.storage.local.get(['settings', 'normalDownloadBaselines'], (res) => {
      if (res.settings?.autoIntercept !== false) return;

      const startTime = Date.parse(item.startTime || '');
      const endTime = Date.parse(item.endTime || '');
      const durationMs = endTime - startTime;
      if (!Number.isFinite(durationMs) || durationMs <= 0) {
        console.warn('[AI Downloader] Could not measure normal download duration:', item.id);
        return;
      }

      const baseline = {
        url: item.url,
        finalUrl: item.finalUrl,
        filename: item.filename.split(/[\\/]/).pop(),
        fileSize: item.fileSize || item.totalBytes,
        durationMs,
        measuredAt: Date.now()
      };
      const baselines = Array.isArray(res.normalDownloadBaselines)
        ? res.normalDownloadBaselines
        : [];
      const existingIndex = baselines.findIndex((entry) =>
        entry.url === baseline.url || entry.finalUrl === baseline.finalUrl
      );
      if (existingIndex >= 0) {
        baselines[existingIndex] = baseline;
      } else {
        baselines.push(baseline);
      }

      chrome.storage.local.set({
        normalDownloadBaselines: baselines.slice(-20)
      }, () => {
        console.log('[AI Downloader] Normal Chrome baseline recorded:', baseline.filename);
        broadcastToPopup({ type: 'BASELINE_RECORDED', filename: baseline.filename });
      });
    });
  });
});

/**
 * Start Accelerated Download
 */
async function startAcceleratedDownload(url, meta = {}) {
  await historyReady;
  try {
    const parsed = new URL(url);
    if (!['http:', 'https:'].includes(parsed.protocol)) throw new Error('Unsupported URL scheme');
  } catch {
    return { success: false, error: 'Enter a valid HTTP or HTTPS URL.' };
  }
  if (!nativeClient.isConnected) {
    return { success: false, error: 'The companion is not connected.' };
  }
  return usageLimit.start(() => dispatchAcceleratedDownload(url, meta));
}

async function dispatchAcceleratedDownload(url, meta) {
  const downloadId = 'dl_' + Date.now() + '_' + Math.random().toString(36).substr(2, 6);
  const { settings } = await chrome.storage.local.get(['settings']);
  const mode = settings?.mode || 'hyper_speed';

  // Evaluate AI Strategy Heuristic
  const strategy = StrategyHeuristic.evaluate({
    url,
    totalBytes: meta.totalBytes || 0,
    mimeType: meta.mimeType || '',
    acceptRanges: true,
    mode,
    latencyMs: 35
  });

  const downloadItem = {
    id: downloadId,
    url,
    filename: meta.filename || extractFilename(url),
    totalBytes: meta.totalBytes || 0,
    downloadedBytes: 0,
    speedBytesPerSec: 0,
    concurrency: strategy.concurrency,
    chunkSize: strategy.chunkSize,
    strategy,
    status: 'starting',
    createdAt: Date.now()
  };

  activeDownloads.set(downloadId, downloadItem);
  persistDownloadState();

  // Extract browser session cookies & referer
  let cookieHeader = '';
  try {
    const cookies = await chrome.cookies.getAll({ url });
    if (cookies && cookies.length > 0) {
      cookieHeader = cookies.map(c => `${c.name}=${c.value}`).join('; ');
    }
  } catch (err) {
    console.debug('Cookie extraction skipped:', err);
  }

  const customHeaders = {};
  if (cookieHeader) customHeaders['Cookie'] = cookieHeader;
  if (meta.referer) customHeaders['Referer'] = meta.referer;
  else if (meta.tabUrl) customHeaders['Referer'] = meta.tabUrl;
  if (meta.method === 'POST' && meta.referer) {
    customHeaders['Origin'] = new URL(meta.referer).origin;
    customHeaders['Content-Type'] = 'application/x-www-form-urlencoded';
  }
  customHeaders['User-Agent'] = navigator.userAgent;

  // Send instruction to Native Companion
  try {
    nativeClient.send({
      command: 'START_DOWNLOAD',
      id: downloadId,
      url: url,
      filename: downloadItem.filename,
      method: meta.method || 'GET',
      body: meta.body || null,
      concurrency: strategy.concurrency,
      chunkSize: strategy.chunkSize,
      enableChunkStealing: strategy.enableChunkStealing,
      tcpNoDelay: strategy.tcpNoDelay,
      preallocateDisk: strategy.preallocateDisk,
      headers: customHeaders
    });
    return { success: true };
  } catch (err) {
    console.warn('[AI Downloader] Native companion not ready, updating status:', err);
    downloadItem.status = 'companion_offline';
    downloadItem.error = 'Native companion is not connected. Install and register the companion separately, then reload the extension.';
    persistDownloadState();
    broadcastToPopup({ type: 'DOWNLOAD_FAILED', item: downloadItem });
    return { success: false, error: err.message };
  }
}

function extractFilename(url) {
  try {
    const parsed = new URL(url);
    const parts = parsed.pathname.split('/').filter(Boolean);
    if (parts.length > 0) {
      return decodeURIComponent(parts[parts.length - 1]);
    }
  } catch (_) {}
  return 'downloaded_file_' + Date.now();
}

async function persistDownloadState() {
  try {
    await historyReady;
    await writeHistory();
  } catch (error) {
    console.error('[AI Downloader] Could not save download history:', error);
  }
}

function broadcastToPopup(message) {
  chrome.runtime.sendMessage(message).catch(() => {
    // Popup might be closed; ignore error
  });
}

function broadcastCompanionStatus(message) {
  broadcastToPopup(message);
  chrome.tabs.query({}, (tabs) => {
    if (chrome.runtime.lastError) {
      console.warn('Could not update companion status in tabs:', chrome.runtime.lastError.message);
      return;
    }
    for (const tab of tabs) {
      if (tab.id !== undefined) {
        chrome.tabs.sendMessage(tab.id, message).catch(() => {
          // Restricted pages and tabs without the content script cannot receive messages.
        });
      }
    }
  });
}

// Runtime messages from Popup
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  historyReady.then(() => handleMessage(request, sender, sendResponse)).catch(error => {
    console.error('[AI Downloader] Download history unavailable:', error);
    sendResponse({ success: false, error: 'Download history could not be loaded.' });
  });
  return true;
});

function handleMessage(request, sender, sendResponse) {
  if (request.type === 'BYPASS_AUTO_INTERCEPT') {
    try {
      const url = new URL(request.url);
      if (url.protocol !== 'http:' && url.protocol !== 'https:') {
        sendResponse({ success: false, error: 'Unsupported URL scheme' });
        return true;
      }
      temporarilyBypassedUrls.set(url.href, Date.now() + 5 * 60 * 1000);
      sendResponse({ success: true });
    } catch (error) {
      sendResponse({ success: false, error: error.message });
    }
    return true;
  }
  if (request.type === 'GET_ACTIVE_DOWNLOADS') {
    sendResponse({ downloads: Array.from(activeDownloads.values()) });
    return true;
  }
  if (request.type === 'TRIGGER_DOWNLOAD') {
    startAcceleratedDownload(request.url, request.meta || {}).then(sendResponse).catch(error => {
      console.error('Download could not start:', error);
      sendResponse({ success: false, error: error.message });
    });
    return true;
  }
  if (request.type === 'TRIGGER_BATCH_DOWNLOAD') {
    sendResponse({ success: false, error: 'Batch downloads require Premium, which is not yet available.' });
    return true;
  }
  if (request.type === 'GET_USAGE') {
    usageLimit.status().then(sendResponse).catch(error => {
      console.error('Could not read download allowance:', error);
      sendResponse({ success: false, error: 'Could not read download allowance.' });
    });
    return true;
  }
  if (request.type === 'FALLBACK_BROWSER_DOWNLOAD') {
    try {
      const url = new URL(request.url);
      if (!['http:', 'https:'].includes(url.protocol)) throw new Error('Unsupported URL scheme');
      temporarilyBypassedUrls.set(url.href, Date.now() + 5 * 60 * 1000);
      chrome.downloads.download({ url: url.href }).then(
        () => sendResponse({ success: true }),
        error => sendResponse({ success: false, error: error.message })
      );
    } catch (error) {
      sendResponse({ success: false, error: error.message });
    }
    return true;
  }
  if (request.type === 'GET_STATUS') {
    if (!nativeClient.isConnected) nativeClient.connect();
    sendResponse({
      isConnected: nativeClient.isConnected,
      lastError: nativeClient.lastError || null,
      extensionId: chrome.runtime.id
    });
    return true;
  }
  if (request.type === 'RECONNECT_COMPANION') {
    nativeClient.connect();
    sendResponse({ isConnected: nativeClient.isConnected });
    return true;
  }
  if (request.type === 'CLEAR_COMPLETED') {
    for (const [id, item] of Array.from(activeDownloads.entries())) {
      if (['completed', 'failed', 'companion_offline', 'interrupted'].includes(item.status)) {
        activeDownloads.delete(id);
      }
    }
    persistDownloadState();
    sendResponse({ success: true });
    return true;
  }
  if (request.type === 'PAUSE_DOWNLOAD') {
    const item = activeDownloads.get(request.id);
    if (!item || !['starting', 'downloading'].includes(item.status)) {
      sendResponse({ success: false, error: 'This download cannot be paused.' });
      return true;
    }
    try {
      nativeClient.send({ command: 'PAUSE_DOWNLOAD', id: request.id });
      item.status = 'paused';
      item.speedBytesPerSec = 0;
      persistDownloadState();
      broadcastToPopup({ type: 'DOWNLOAD_PROGRESS', item });
      sendResponse({ success: true });
    } catch (error) {
      sendResponse({ success: false, error: error.message });
    }
    return true;
  }
  if (request.type === 'RESUME_DOWNLOAD') {
    const item = activeDownloads.get(request.id);
    if (!item || item.status !== 'paused') {
      sendResponse({ success: false, error: 'This download is not paused.' });
      return true;
    }
    try {
      nativeClient.send({ command: 'RESUME_DOWNLOAD', id: request.id });
      item.status = 'downloading';
      persistDownloadState();
      broadcastToPopup({ type: 'DOWNLOAD_PROGRESS', item });
      sendResponse({ success: true });
    } catch (error) {
      sendResponse({ success: false, error: error.message });
    }
    return true;
  }
  if (request.type === 'CANCEL_DOWNLOAD') {
    try {
      nativeClient.send({ command: 'CANCEL_DOWNLOAD', id: request.id });
    } catch (error) {
      sendResponse({ success: false, error: error.message });
      return true;
    }
    activeDownloads.delete(request.id);
    persistDownloadState();
    broadcastToPopup({ type: 'DOWNLOAD_PROGRESS' });
    sendResponse({ success: true });
    return true;
  }
}
