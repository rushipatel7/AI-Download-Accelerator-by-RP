// Set this to a Stripe test-mode Payment Link after creating the test product.
export const stripeTestPaymentLink = 'https://buy.stripe.com/test_8x28wRbCv0U48398eN1wY00';
